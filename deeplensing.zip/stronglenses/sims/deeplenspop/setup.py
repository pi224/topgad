from setuptools import setup
import os
import sys
from setuptools.command.test import test as TestCommand
from setuptools import find_packages

try:
        from setuptools import setup
except ImportError:
        from distutils.core import setup


# create package path
PACKAGE_PATH = os.path.abspath(os.path.join(__file__, os.pardir))


setup(name='deeplenspop',
      version='0.1',
      description='deeplenspop',
      url='https://github.com/bnord/deeplenspop',
      packages=find_packages(PACKAGE_PATH, "test"),
      include_package_data=True,
      package_dir={'deeplenspop': 'deeplenspop'},
      author='Brian Nord, Tom Collett (original)',
      author_email='briandnord@gmail.com',
      license='MIT',
      #packages=['deeplenspop'],
      zip_safe=False)
