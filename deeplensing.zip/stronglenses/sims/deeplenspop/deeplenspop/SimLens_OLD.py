# import os
import pprint
import sys
from FastLensSim import *
from ColorizeFunction import Colorize
# logging
import logging.config
import numpy as np
import cPickle

pp = pprint.PrettyPrinter(indent=4)


class SimLens(object):
    """
    """

    def __init__(self):
        self.xblah = 0.
        self.verbose_debug = False

# --------------------------------------------------------------------

    def read_lenspars(self, myfile):
        """read pickle file"""
        myf = open(myfile, 'rb')
        data = cPickle.load(myf)
        myf.close()
        return data

# --------------------------------------------------------------------

    def save_lenspars(self, data, myfile):
        """save data to file"""
        myf = open(myfile, 'wb')
        cPickle.dump(data, myf)
        myf.close()
        return

# --------------------------------------------------------------------

    def generate_lens_image(self, lenspars, lens_class,
                            survey="Custom",
                            psf_fac=1.0,
                            exp_fac=1.0,
                            Nside_pix=32
                            ):
        """generate image data for one lens or non-lens"""
        # survey = "Custom"
        nsources = 1
        SNcutA = 10
        magcut = 0
        SNcutBmin = 0
        SNcutBmax = 0
        myfloor = 999
        # exp_fac = 1.0

        # Create Survey Simulation set
        SimSet = FastLensSim(survey, Nside_pix=Nside_pix)
        SimSet.bfac = float(100000)  # high allows object to always be observed
        SimSet.rfac = float(0)     # low allows object to always be observed
        SimSet.exposuretimes['g_SDSS'] *= exp_fac
        SimSet.exposuretimes['r_SDSS'] *= exp_fac
        SimSet.exposuretimes['i_SDSS'] *= exp_fac

        # visible magnitude value
        lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                                 lenspars["rl"]["i_SDSS"] +
                                 lenspars["rl"]["z_SDSS"]) / 3

        # mi in ml
        for mi in [lenspars["ml"], lenspars["ms"][1]]:
            mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

        lenspars["mag"] = {}
        lenspars["msrc"] = {}
        lenspars["mag"] = {}
        lenspars["msrc"] = {}
        lenspars["SN"] = {}
        lenspars["bestband"] = {}
        lenspars["pf"] = {}
        lenspars["resolved"] = {}
        lenspars["poptag"] = {}
        lenspars["seeing"] = {}
        lenspars["rfpf"] = {}
        lenspars["rfsn"] = {}

        SimSet.setLensPars(lenspars["ml"],
                           lenspars["rl"],
                           lenspars["ql"],
                           reset=True)

        # set source parameters
        for j in range(nsources):
            jj = j + 1
            SimSet.setSourcePars(lenspars["b"][jj],
                                 lenspars["ms"][jj],
                                 lenspars["xs"][jj],
                                 lenspars["ys"][jj],
                                 lenspars["qs"][jj],
                                 lenspars["ps"][jj],
                                 lenspars["rs"][jj],
                                 sourcenumber=jj)
        if self.verbose_debug:
            print "len pre", len(SimSet.image)
        SimSet.makeLens(stochasticmode="MP",
                        musthaveallbands=True,
                        psf_fac=psf_fac,
                        myfloor=myfloor)
        SOdraw = numpy.array(SimSet.SOdraw)
        if self.verbose_debug:
            print "len primary", len(SimSet.image)

        mag, msrc, SN, bestband, pf = \
            SimSet.SourceMetaData(SNcutA=SNcutA,
                                  magcut=magcut,
                                  SNcutB=[SNcutBmin, SNcutBmax])

        # create some lenspars elements
        lenspars["SN"][survey] = {}
        lenspars["bestband"][survey] = {}
        lenspars["pf"][survey] = {}
        lenspars["resolved"][survey] = {}
        lenspars["seeing"][survey] = SimSet.seeing

        rfpf = {}
        rfsn = {}
        for src in SimSet.sourcenumbers:
            rfpf[src] = False
            rfsn[src] = [0]
            lenspars["mag"][src] = mag[src]
            lenspars["msrc"][src] = msrc[src]
            lenspars["SN"][survey][src] = SN[src]
            lenspars["bestband"][survey][src] = bestband[src]
            lenspars["pf"][survey][src] = pf[src]
            lenspars["resolved"][survey][src] = SimSet.resolved[src]

        if self.verbose_debug:
            print "len secondary", len(SimSet.image)

        SimSet.makeLens(noisy=True,
                        stochasticmode="MP",
                        SOdraw=SOdraw,
                        musthaveallbands=True,
                        MakeModel=True,
                        psf_fac=psf_fac,
                        myfloor=myfloor)

        lenspars["rfpf"][survey] = rfpf
        lenspars["rfsn"][survey] = rfsn

        return SimSet

# --------------------------------------------------------------------

    def generate_lenspars(self, zl, zs, be, xs, ys, lens_class):
        """Set lens pars"""

        # 'g_SDSS': 24.370519353475789,
        # 'i_SDSS': 20.992404985468962,
        # 'r_SDSS': 22.433858036695487,
        lenspars = {
            'b': {1: 1.50459557390608167},
            'lens?': True,
            'mhalo': {1: 0.58579999999999999},
            'ml': {'F814W_ACS': 23.700488839837011,
                   'Y_UKIRT': 99.987330016400776,
                   'z_SDSS': 23.384894670188533,
                   'g_SDSS': 22.0,
                   'r_SDSS': 21.6,
                   'i_SDSS': 20.15},
            'ms': {1: {'F814W_ACS': 21.899000000000001,
                       'Y_UKIRT': 2145.7356,
                       'g_SDSS': 22.049399999999999,
                       'i_SDSS': 21.899000000000001,
                       'r_SDSS': 22.091000000000001,
                       'z_SDSS': 21.7044}},
            'mstar': {1: 24.700800000000001},
            'ps': {1: 112.89232455485484},
            'ql': 0.20065521218913041,
            'qs': {1: 0.59850689607147711},
            'rl': {'F814W_ACS': 0.58849609885759535,
                   'Y_UKIRT': 0.58849609885759535,
                   'g_SDSS': 0.58849609885759535,
                   'i_SDSS': 0.58849609885759535,
                   'r_SDSS': 0.58849609885759535,
                   'z_SDSS': 0.58849609885759535},
            'rs': {1: 1.48655683444557},
            'sigl': 197.52337452393428,
            'xs': {1: 4.0},
            'ys': {1: 4.0},
            'zl': 0.64597976934717483,
            'zs': {1: 1.4413}
        }

        lenspars['xs'][1] = xs
        lenspars['ys'][1] = ys
        lenspars['b'][1] = be
        """
        lenspars['zl'] = zl
        lenspars['zs'][1] = zs
        if lens_class == 0:
            lens_class_bool = False
        elif lens_class == 1:
            lens_class_bool = True
        lenspars['lens?'] = lens_class_bool

        # if lens_class_bool is False:
        #    for key, value in lenspars['ms'][1].iteritems():
        #        lenspars['ms'][1][key] = 99.
        """

        return lenspars

# --------------------------------------------------------------------

    def generate_lenspars_set(self, params, lens_class):
        """ generate sample of lenspars """

        lenspars_set = {}
        for i, param in zip(range(len(params)), params):

            [zl, zs, be, xs, ys] = param
            lenspars = self.generate_lenspars(zl, zs, be, xs, ys, lens_class)
            lenspars_set[i] = lenspars

        return lenspars_set

# --------------------------------------------------------------------

    def generate_run_path(self, dir_output, run_number, overwrite=False):
        """ create run path string """

        run_path = dir_output + "Run" + str(run_number).zfill(3) + "/"
        if not os.path.exists(run_path):
            os.makedirs(run_path)
        else:
            print "path exists"
            if overwrite is False:
                print "you have chosen to NOT overwrite this directory"
                sys.exit()
            elif overwrite is True:
                print "you have chosen to overwrite this directory of data"

        return run_path

# --------------------------------------------------------------------

    def generate_training_sample(self,
                                 Nlens, Nnons, zl, zs,
                                 run_number,
                                 psf_fac=1.0,
                                 exp_fac=1.0,
                                 Nside_pix=32,
                                 brange=[0.1, 2.0],
                                 xsrange=[0.0, 7.0],
                                 ysrange=[0.0, 9.0],
                                 seed=827282,
                                 shuffle=True,
                                 save_lenspars=True,
                                 survey="Custom",
                                 run_path="./data/"):
        """ generate full training sample of both lenses and non-lenses"""

        # generate lens pars
        print "generate random variables"
        params_lens = self.generate_lenspars_params(Nlens, zl, zs, True,
                                                    seed=seed,
                                                    brange=brange,
                                                    xsrange=xsrange,
                                                    ysrange=ysrange)
        params_nons = self.generate_lenspars_params(Nnons, zl, zs, False,
                                                    seed=seed,
                                                    brange=brange,
                                                    xsrange=xsrange,
                                                    ysrange=ysrange)

        print "generate lensparsets"
        lenspars_set_lens = self.generate_lenspars_set(params_lens, True)
        lenspars_set_nons = self.generate_lenspars_set(params_nons, False)

        print "save lensparsets to file"
        if save_lenspars:
            myfile_lens = run_path + "lenspars_set_lens.pkl"
            myfile_nons = run_path + "lenspars_set_nons.pkl"
            self.save_lenspars(lenspars_set_lens, myfile_lens)
            self.save_lenspars(lenspars_set_nons, myfile_nons)

        # generate lens image sample
        print "generate lens sample"
        data_lens, labels_lens, ids_lens = \
            self.generate_lens_sample(lenspars_set_lens,
                                      lens_class=True,
                                      save_color_image=True,
                                      run_path=run_path,
                                      survey=survey,
                                      psf_fac=psf_fac,
                                      exp_fac=exp_fac,
                                      Nside_pix=Nside_pix,
                                      verbose_object=True)

        print "generate non lens sample"
        data_nons, labels_nons, ids_nons = \
            self.generate_lens_sample(lenspars_set_nons,
                                      lens_class=False,
                                      save_color_image=True,
                                      run_path=run_path,
                                      survey=survey,
                                      psf_fac=psf_fac,
                                      exp_fac=exp_fac,
                                      Nside_pix=Nside_pix,
                                      verbose_object=True)

        # concatenate data arrays
        print "concatenate arrays"
        data = np.concatenate((data_lens, data_nons))
        labels = np.concatenate((labels_lens, labels_nons))

        # shuffle concatenated data
        if shuffle:
            print "shuffle arrays"
            arr = np.arange(Nlens + Nnons)
            np.random.shuffle(arr)

            data = data[arr]
            labels = labels[arr]

        return data, labels

# --------------------------------------------------------------------

    def generate_lenspars_params(self,
                                 Nobject, zl, zs, lens_class,
                                 brange=[0.1, 2.0],
                                 xsrange=[0.0, 7.0],
                                 ysrange=[0.0, 9.0],
                                 seed=827282):
        """ generate sample of lenspars """

        # set ranges
        bmin, bmax = brange[0], brange[1]
        xsmin, xsmax = xsrange[0], xsrange[1]
        ysmin, ysmax = ysrange[0], ysrange[1]

        # redshift lists
        zl_list = np.ones(Nobject) * zl
        zs_list = np.ones(Nobject) * zs

        # set lists
        b_list = []
        xs_list = []
        ys_list = []
        Nobject_have = 0
        np.random.seed(seed)
        while Nobject_have < Nobject:
            b_tmp = np.random.uniform(bmin, bmax)
            xs_tmp = np.random.uniform(xsmin, xsmax)
            ys_tmp = np.random.uniform(ysmin, ysmax)
            lens_status = self.check_lens_status(xs_tmp, ys_tmp,
                                                 b_tmp, lens_class)
            if lens_status:
                b_list.append(b_tmp)
                xs_list.append(xs_tmp)
                ys_list.append(ys_tmp)
                Nobject_have = len(b_list)

        # convert to numpy arrays
        b_list = np.array(b_list)
        xs_list = np.array(xs_list)
        ys_list = np.array(ys_list)

        # store params
        params = [np.array([zli, zsi, bi, xsi, ysi])
                  for zli, zsi, bi, xsi, ysi
                  in zip(zl_list, zs_list, b_list, xs_list, ys_list)]

        params = np.array(params)

        return params

# --------------------------------------------------------------------

    def check_lens_status(self, xs_tmp, ys_tmp, b_tmp, lens_class):
        """ check whether the object is a lens or not """

        # measure distance of source
        # radius = np.sqrt(xs_tmp**2 + ys_tmp**2)
        radius2 = xs_tmp**2 + ys_tmp**2
        radius = np.sqrt(radius2)

        # get boolean for within einstein radius
        within = bool(radius < b_tmp)
        # within2 = bool(radius2 < (b_tmp**2))
        # if within is not within2:
        #     print 'wtf mate'

        # check if meets class
        if within is lens_class:
            return True
        else:
            return False

# --------------------------------------------------------------------

    def check_seeing(self, seeing):
        see_sum = np.sum([see for k, see in seeing.iteritems()])
        if see_sum > 0.:
            pass_seeing = True
        elif see_sum == 0.:
            pass_seeing = False
        return pass_seeing

# --------------------------------------------------------------------

    def check_photom(self, lenspars,
                     mag_limit=22,
                     band_list=['g_SDSS', 'r_SDSS', "i_SDSS"],
                     pass_dict={0: False, 1: False, 2: False, 3: True},
                     mag_type="lens"):
        """check photometric magnitudes for passing a cut"""
        if mag_type == "lens":
            photom = lenspars["ml"]
        elif mag_type == "src":
            photom = lenspars['ms'][1]

        # photom = lenspars['ml']
        mag_list = np.array([mag
                            for label, mag in photom.iteritems()
                            if label in band_list])
        check_limit = len(np.where(mag_list < mag_limit)[0])
        pass_photom = pass_dict[check_limit]
        # print mag_limit, check_limit
        # print mag_list, pass_photom

        return pass_photom

    def check_photom_src(self, lenspars, mag_limit=22):
        # see_sum = np.sum([see for k, see in seeing.iteritems()])
        photom = lenspars['ms'][1]
        band_list = ['g_SDSS', 'r_SDSS', "i_SDSS"]
        count_pass = 0
        for label, mag in photom.iteritems():
            if label in band_list:
                if mag < mag_limit:
                    count_pass += 1

        if count_pass >= len(band_list):
            pass_photom = True
        else:
            pass_photom = False

        return pass_photom


# --------------------------------------------------------------------

    def generate_lens_sample(self,
                             lenspars_set,
                             lens_class,
                             mag_limit_lens=22.,
                             mag_limit_src=25.,
                             psf_fac=1.0,
                             exp_fac=1.0,
                             Nside_pix=32,
                             save_color_image=False,
                             run_path="./data/",
                             verbose_object=False,
                             survey="Custom"):
        """generate sample of lenses from set of lenspars"""

        data = []
        Ndata = len(lenspars_set)
        ids = []
        count_lens = 0
        for i, lenspars in lenspars_set.iteritems():

            if not lenspars['lens?']:
                print lenspars['lens?']

            SimSet = self.generate_lens_image(lenspars, lens_class,
                                              psf_fac=psf_fac,
                                              exp_fac=exp_fac,
                                              Nside_pix=Nside_pix,
                                              survey=survey)

            if self.verbose_debug:
                print 'object', i, lens_class, len(SimSet.image)

            # vestige of photometry check
            pass_photom_lens = pass_photom_src = True

            if pass_photom_lens and pass_photom_src:
                # create array format for output
                img = [y for x, y in SimSet.image.iteritems()]
                data.append(img)
                ids.append(i)
                count_lens += 1

                # pp.pprint(lenspars)

                # save color image
                if save_color_image:

                    # check class for file and dir names
                    if lens_class is False:
                        name_tag = "nons"
                    elif lens_class is True:
                        name_tag = "lens"

                    # name
                    dir_output = run_path + name_tag + "/"
                    outfile = "img_" + name_tag + \
                        "_" + str(i).zfill(5) + ".png"

                    # make output directory
                    if not os.path.exists(dir_output):
                        os.makedirs(dir_output)

                    self.save_image(SimSet,
                                    survey="lssta",
                                    dir_output=dir_output,
                                    outfile=outfile)

                if verbose_object:
                    print "object: " + str(i + 1).zfill(4) +\
                        " / " + str(Ndata).zfill(4), count_lens
            if self.verbose_debug:
                print
                print
                print

        # make the data an array
        data = np.array(data)
        Ndata = len(data)

        # make labels
        labels = self.generate_labels(Ndata, lens_class)

        # make the id values an array
        ids = np.array(ids)

        if Ndata == 0:
            data = None
            labels = None

        return data, labels, ids

# --------------------------------------------------------------------

    def generate_labels(self, Ndata, lens_class):
        """generate labels for class of objects"""

        labels = np.ones(Ndata, dtype=int) * lens_class

        return labels

# --------------------------------------------------------------------

    def check_source_position_limits(self, xsrange, ysrange, Nside_pix):
        """Check if the source position maximum value is
        beyond the range of having
        an efficient placement of sources"""

        Nside_sec = Nside_pix * 0.263
        print "nside sec", Nside_sec
        Nside_sec_half = Nside_sec / 2.

        xmax_abs = max([abs(xs) for xs in xsrange])
        ymax_abs = max([abs(ys) for ys in ysrange])
        rmax = np.sqrt(xmax_abs**2 + ymax_abs**2)
        if rmax > Nside_sec_half:
            print "Limits on position ranges create non-lenses inefficiently"
            print "your radius", rmax
            print " max advisable radius", Nside_sec_half
            sys.exit()

# --------------------------------------------------------------------

    def save_image(self, SimSet,
                   survey="Custom",
                   dir_output="./data/ImagesNew/",
                   outfile="test.png",
                   method="colorize"):
        """Save Images"""

        # make directory
        if not os.path.isdir(dir_output):
            os.mkdir(folder)

        if method == "colorize":
            myimage = Colorize(dir_output=dir_output, outfile=outfile,
                               enhLevel=0.3,
                               Q=0.8,
                               Gcor=1.2,
                               Rcor=0.8,
                               Icor=1.0,
                               Alpha=0.06,
                               satCut=0.8)
            band_set = ["g_SDSS", "r_SDSS", "i_SDSS"]
            myimage.read_data_set(band_set, SimSet.image)
            myimage.ProcessFile()
        elif method == "colorimage":
            mydata = SimSet.makeColorLens()
            myshape = mydata.shape
            from PIL import Image
            rgbArray = np.zeros(myshape, 'uint8')
            rgbArray[..., 0] = mydata[:, :, 0] * 256
            rgbArray[..., 1] = mydata[:, :, 1] * 256
            rgbArray[..., 2] = mydata[:, :, 2] * 256
            img = Image.fromarray(rgbArray, 'RGB')
            img.save(dir_output + outfile)

        return

# --------------------------------------------------------------------

    def save_data(self, data, labels, run_path="./data/"):
        """Save Data arrays"""
        np.save(run_path + "xtrain_lenspop.npy", data)
        np.save(run_path + "ytrain_lenspop.npy", labels)
        # np.save(dir_output + 'metadata_lens.npy', metadata)

class SimLensPopulation(SimLens):
    """
    """
    def __init__(self):
        self.test = 0.
        self.verbose_debug = False

    def get_file_info(self, dir_object):
        """get directory and file information"""
        print "dir object", dir_object
        path_tmp, dirs_tmp, files_tmp = os.walk(dir_object).next()
        nb_files = len(files_tmp)
        return path_tmp, files_tmp, nb_files

    def generate_population_sample(self, Nb_requested,
                                   dir_data, lens_class, run_path,
                                   mag_limit_lens=22.,
                                   mag_limit_src=25.,
                                   verbose_object=False,
                                   survey="Custom"):
        """generate full population data set"""
        # get file names
        path_tmp, files_tmp, nb_files = self.get_file_info(dir_data)

        # check if there are any files
        if nb_files < 1:
            print "ain't no files"
            sys.exit()

        # loop over directory
        data = None
        labels = None
        for file_tmp, i in zip(files_tmp, range(nb_files)):

            # read file
            lenspars_set = self.read_lenspars(path_tmp + file_tmp)

            nlens = len(lenspars_set)
            if nlens > 0:
                data_tmp, labels_tmp, ids_tmp = \
                    self.generate_lens_sample(lenspars_set,
                                              lens_class=lens_class,
                                              mag_limit_lens=mag_limit_lens,
                                              mag_limit_src=mag_limit_src,
                                              run_path=run_path,
                                              verbose_object=verbose_object,
                                              survey=survey,
                                              save_color_image=True)

                # concatenate data arrays
                if data_tmp is not None:
                    if data is None:
                        data = data_tmp
                        labels = labels_tmp
                    else:
                        data = np.concatenate((data, data_tmp))
                        labels = np.concatenate((labels, labels_tmp))

                if data is not None:
                    Ndata = len(data)

                    if Ndata >= Nb_requested:
                        return data, labels

                # if i == 10000:
                #    break

        return data, labels

    def generate_pop_training_sample(self,
                                     Nb_lens_requested,
                                     Nb_nons_requested,
                                     mag_limit_lens=22.,
                                     mag_limit_src=25.,
                                     run_path="./data/",
                                     survey="Custom",
                                     verbose_object=False):
        # run_number = 3
        shuffle = True

        # make direcotry names
        dir_base = run_path + "idealisedlenses/"

        # directory
        dir_lens = dir_base + "lens/"
        dir_nons = dir_base + "nons/"
        print dir_lens

        print "make lenses"
        data_lens, labels_lens = \
            self.generate_population_sample(Nb_lens_requested, dir_lens,
                                            True,
                                            run_path,
                                            mag_limit_lens=22.,
                                            mag_limit_src=25.,
                                            survey=survey,
                                            verbose_object=verbose_object)

        print "make non-lenses"
        data_nons, labels_nons = \
            self.generate_population_sample(Nb_nons_requested, dir_nons,
                                            False,
                                            run_path,
                                            mag_limit_lens=22.,
                                            mag_limit_src=25.,
                                            survey=survey,
                                            verbose_object=verbose_object)

        data = np.concatenate((data_lens, data_nons))
        labels = np.concatenate((labels_lens, labels_nons))

        # shuffle concatenated data
        if shuffle:
            Nlens = len(data_lens)
            Nnons = len(data_nons)
            Ntot = Nlens + Nnons
            print "shuffle arrays"
            arr = np.arange(Ntot)
            np.random.shuffle(arr)

            data = data[arr]
            labels = labels[arr]

        return data, labels

# ================================================
# Metadata logging
# ================================================
# ------------------------------------------------------------------------------
def make_metadata_log(my_system):
    """Create Data Dictionary."""
    metadata_log = my_system.__dict__
    log.info("Make Meta data Log")
    try: 
        del metadata_log["model"]
    except:
        pass
    try:
        del metadata_log["history"]
    except:
        pass

    return metadata_log

    
# ------------------------------------------------------------------------------
def update_metadata_log(metadata_log, **kwargs):
    """Update Data Dictionary."""
    # loop over keyword arguments
    for k,v in kwargs.iteritems():
        metadata_log[k] = v

    return metadata_log


# ------------------------------------------------------------------------------
def save_metadata_log(dir_runlist, metadata_log, id_model=None, id_analysis=None):
    """Save Model Data Dictionary."""
    if id_model is not None:
        f_io =  "Model" + str(id_model).zfill(3) + "_Log" + ".json"
    if id_analysis is not None:
        f_io =  "Analysis" + str(id_analysis).zfill(3) + "_Log" + ".json"
    
    f_io_full = dir_runlist + f_io
  
    with open(f_io_full, 'w') as f:
        json.dump(metadata_log, f, sort_keys = True, indent = 4)


# ------------------------------------------------------------------------------
def load_metadata_log(dir_runlist, id_model=None, id_analysis=None):
    """Save Model Data Dictionary."""
    if id_model is not None:
        f_io =  "Model" + str(id_model).zfill(3) + "_Log" + ".json"
    if id_analysis is not None:
        f_io =  "Analysis" + str(id_analysis).zfill(3) + "_Log" + ".json"
    
    f_io_full = dir_runlist + f_io
  
    with open(f_io_full) as data_file:    
        metadata_log = json.load(data_file)

    return metadata_log


# ------------------------------------------------------------------------------
def collate_metadata_log(dir_runlist):
    """Collate Data Dictionary into single file."""
    file_io_list = [os.path.join(dir_runlist, f) for f in os.listdir(dir_runlist) if os.path.isfile(os.path.join(dir_runlist, f))]

    i_count = 0
    for f_io in file_io_list:
        with open(f_io) as data_file:    
            metadata = json.load(data_file)
        
        for k, v in metadata.iteritems():
            metadata[k] = [v]

        metadata = Table(metadata)
        if i_count == 0:
            metadata_master = metadata
        else:
            metadata_master = vstack([metadata_master, metadata], join_type='outer')
        
        i_count += 1

    """
    names = metadata_master.colnames
    edit_list = ["id_model", "id_data_train", "id_data_valid", "id_data_test"]
    for iname, name in zip(range(len(edit_list)), edit_list):
        try:
            names.remove(name)
            names.insert(iname, name)
        except:
            pass
    """

    file_io_master = "./Metadata_master_log.csv"
    ascii.write(metadata_master, file_io_master, 
                delimiter=",", 
    #            names=names,
                fill_values=[(ascii.masked, '---')])



# ------------------------------------------------------------------------------
# def make_log(id_data, id_model, id_analysis=None):
def setup_logging(default_path='logging.json', 
             default_level=logging.INFO,
             env_key='LOG_CFG'): 
    """Log all output data."""
    # file_log = make_log_name(id_data, id_model, id_analysis=id_analysis)

    # file_log = "./test_log.txt"
    try:  # Python 2.7+
        from logging import NullHandler
    except ImportError:
        class NullHandler(logging.Handler):
            """Class null handler."""
            
            def emit(self, record):
                """Emit."""
                pass
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            myconfig = json.load(f)
        logging.config.dictConfig(myconfig)
    else:
        logging.basicConfig(level=default_level)

    # logging.getLogger(__name__)
    # logging.getLogger(__name__).addHandler(NullHandler())

    """
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=default_level)

    # Set default logging handler to avoid "No handler found" warnings.
    import logging
    try:  # Python 2.7+
        from logging import NullHandler
    except ImportError:
        class NullHandler(logging.Handler):
            def emit(self, record):
                pass

    logging.getLogger(__name__).addHandler(NullHandler())
    """

    return 


