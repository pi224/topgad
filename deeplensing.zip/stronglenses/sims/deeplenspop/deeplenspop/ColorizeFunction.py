#!/usr/bin/env python
import sys
import numpy
import math
import pyfits
from PIL import Image
from PIL import PngImagePlugin
import exceptions
import time
import os
from os import listdir, symlink, makedirs
from os.path import isfile, join, exists


'''
Input parameters are provided in a single input file similar to following:
sigmaMin=1     # level of noise in the image
sigmaMax=12    # not really used
Rcor=1.0       # these correction factors can be considered as quantum efficiency
Gcor=1.0       # of the CCD to given band
Icor=1.0
enhLev=0.2     # additional EnhanceImagement of red and blue for contrast in search of strong lensing
               # one can play with value 0 - 0.2 and sign  of the correction. 0.2 will increase
               # blue and decrease red.
satCut=0.8     # changes maximal value before saturation. The lower its value the brighter faint
               # objects will be and the more saturation.
Q=1.0          # Q factor in Lupton's scaling. Increase it to see fainter objects and more noise.
               # Recommended values 1.0 - 3.0
Alpha=0.06     # recommended values from 0.03  to 0.06. Also changes brightness and contrast.

'''


class Colorize(exceptions.Exception):
    """class of objects to be colorized"""

    # Initialize
    def __init__(self,
                 zp=30.0,
                 enhLevel=0.4,  # 0.1
                 Rcor=1.0,  # 0.8
                 Gcor=1.0,  # 0.2
                 Icor=1.0,  # 0.8
                 Q=0.3,
                 Alpha=0.0006,
                 satCut=1.2,
                 filters=['R', 'G', 'I'],
                 sigmaMin=1,
                 sigmaMax=6,
                 scaleType="arcsinh",
                 outfile="test.png",
                 dir_output=None
                 ):

        # Colorize Settings (User Input)
        '''
        self.zp         = 30.0
        self.enhLevel   = 0.0
        self.Rcor       = 1.0
        self.Gcor       = 1.0
        self.Icor       = 1.0
        self.Q          = 1.0
        self.Alpha      = 0.06
        self.satCut     = 0.8
        self.filters    = ['R','G','I']
        self.sigmaMin   = 2
        self.sigmaMax   = 6
        self.scaleType = "arcsinh"
        self.outfile    = "test"
        '''

        self.dir_input = None
        self.filenameG = None
        self.filenameR = None
        self.filenameI = None

        self.dir_output = dir_output + "/"
        self.zp = zp
        self.enhLevel = enhLevel
        self.Rcor = Rcor
        self.Gcor = Gcor
        self.Icor = Icor
        self.Q = Q
        self.Alpha = Alpha
        self.satCut = satCut
        self.filters = filters
        self.sigmaMin = sigmaMin
        self.sigmaMax = sigmaMax
        self.scaleType = scaleType
        self.outfile = outfile

        self.make_image_time = 0.

        # Input FITS image header values
        self.crpix1 = 0
        self.crpix2 = 0
        self.crval1 = 0
        self.crval2 = 0
        self.cd1_1 = 0
        self.cd1_2 = 0
        self.cd2_1 = 0
        self.cd2_2 = 0
        self.nrow = 0
        self.ncol = 0

        # Working Quantities
        self.S = {}
        self.zpFf = {}
        self.zpF = {}
        self.stamps = {}
        self.impars = {}
        self.maxP = {}
        self.delta = {}

    def read_data_set(self, band_set, stamp_set):
        self.stamps['G'] = stamp_set[band_set[0]]
        self.stamps['R'] = stamp_set[band_set[1]]
        self.stamps['I'] = stamp_set[band_set[2]]
        (self.nrow, self.ncol) = stamp_set[band_set[0]].shape

    def read_data_object(self, band, stamp):
        self.stamps[band] = stamp
        (self.nrow, self.ncol) = stamp.shape

    def read_data_files(self, dir_input, filenameG, filenameR, filenameI):
        # update stamp information

        self.dir_input = dir_input
        self.dir_output = self.dir_input
        self.filenameG = dir_input + filenameG
        self.filenameR = dir_input + filenameR
        self.filenameI = dir_input + filenameI

        self.stamps['G'] = self.ReadFits(self.filenameG)
        self.stamps['R'] = self.ReadFits(self.filenameR)
        self.stamps['I'] = self.ReadFits(self.filenameI)

    def MakeOutputFileName(self):
        """Make output filename"""

        # make output file name
        self.outfile = self.dir_output + self.outfile
        # print self.outfile

    def ReadFits(self, fitsfile):
        """Read Fits File"""

        fitsfile = os.path.normpath(fitsfile)
        hdulist = pyfits.open(fitsfile)
        prihdr = hdulist[0].header

        try:
            self.ncol = prihdr["NAXIS1"]
            self.nrow = prihdr["NAXIS2"]
            # expTime = prihdr["EXPTIME"]
            self.crpix1 = prihdr["CRPIX1"]
            self.crpix2 = prihdr["CRPIX2"]
            self.crval1 = prihdr["CRVAL1"]
            self.crval2 = prihdr["CRVAL2"]
            self.cd1_1 = prihdr["CD1_1"]
            self.cd1_2 = prihdr["CD1_2"]
            self.cd2_1 = prihdr["CD2_1"]
            self.cd2_2 = prihdr["CD2_2"]
        except:
            # print "This information not available in fits image header"
            pass

        try:
            self.zp = prihdr["SEXMGZPT"]
        except:
            pass
            #  self.zp = 30.

        image = hdulist[0].data
        hdulist.close()

        return image

    def GetStampParameters(self, image):
        """calculate parameters of the image median, max value and sigma"""

        subim = numpy.copy(image)
        subim = numpy.where(subim >= -19.9, subim, -19.9)
        subim = numpy.where(subim <= 20., subim, 20.)

        median = numpy.median(subim)
        minP = numpy.min(image)
        maxP = numpy.max(image)
        sigma = numpy.std(subim)

        return [median, minP, maxP, sigma]

    def FilterImage(self, key, sigmaMin, sigmaMax, Fcor):
        """Rescale image to make sigma = 1 and correct on the CCD efficiency"""
        median = self.impars[key][0]
        maxC = self.impars[key][2]
        #        sigma = self.impars[key][3]
        image = self.stamps[key]
        a = (image + self.delta[key] - median)
        a = numpy.where(a >= 0., a, 0.)

        self.S[key] = Fcor
        a = a * Fcor
        self.maxP[key] = (maxC + self.delta[key] - median) * self.S[key]

        return a

    def Rescale(self, key, X, scale):
        """Apply scaling factor and scale maximum to 255"""

        a = X * self.stamps[key]
        a *= scale

        return a

    def Scale(self, c):
        """Scale images"""

        if self.scaleType == "arcsinh":
            return numpy.arcsinh(c)
        elif self.scaleType == "sqrt":
            return numpy.sqrt(c)
        elif self.scaleType == "log":
            return numpy.log10(c)

        return

    def EnhanceImage(self):
        """apply artificial EnhanceImagement to R and B colors"""

        r = self.stamps["I"]
        g = self.stamps["R"]
        b = self.stamps["G"]

        r = r * (1 - self.enhLevel)
        b = b * (1 + self.enhLevel)
        r = numpy.where(r < 255, r, 255)
        g = numpy.where(g < 255, g, 255)
        b = numpy.where(b < 255, b, 255)

        self.stamps["I"] = r.astype(numpy.uint8)
        self.stamps["G"] = b.astype(numpy.uint8)
        self.stamps["R"] = g.astype(numpy.uint8)

        return

    def ProcessFile(self):
        """Perform processing of the input files creating png image stamp"""

        time_start = time.time()

        self.zpF["R"] = self.zp
        self.zpF["G"] = self.zp
        self.zpF["I"] = self.zp


        zpAv = (self.zpF["R"] + self.zpF["G"] + self.zpF["I"]) / 3
        self.Rcor = self.Rcor * math.pow(10, -0.4 * (self.zpF["R"] - zpAv))
        self.Gcor = self.Gcor * math.pow(10, -0.4 * (self.zpF["G"] - zpAv))
        self.Icor = self.Icor * math.pow(10, -0.4 * (self.zpF["I"] - zpAv))

        self.impars['R'] = self.GetStampParameters(self.stamps['R'])
        self.delta['R'] = self.impars['R'][3] * self.sigmaMin

        self.impars['G'] = self.GetStampParameters(self.stamps['G'])
        self.delta['G'] = self.impars['G'][3] * self.sigmaMin

        self.impars['I'] = self.GetStampParameters(self.stamps['I'])
        self.delta['I'] = self.impars['I'][3] * self.sigmaMin

        self.stamps['R'] = self.FilterImage(
            'R', self.sigmaMin, self.sigmaMax, self.Rcor)
        self.stamps['G'] = self.FilterImage(
            'G', self.sigmaMin, self.sigmaMax, self.Gcor)
        self.stamps['I'] = self.FilterImage(
            'I', self.sigmaMin, self.sigmaMax, self.Icor)

        # print " now create scale image "
        Im = self.stamps["R"] + self.stamps["G"] + self.stamps["I"]
        d = Im * self.Q
        d = numpy.where(d <= 0., 0.0001 * self.Q, d)
        c = Im * (self.Q * self.Alpha)
        F = self.Scale(c)
        X = F / d
        maxR = self.maxP['R']
        maxG = self.maxP['G']
        maxB = self.maxP['I']
        maxI = maxR + maxG + maxB

        G = self.Scale(maxI * self.Q * self.Alpha)
        scale = 1765.0 * self.Q / (G * self.satCut)

        self.stamps["R"] = self.Rescale("R", X, scale)
        self.stamps["G"] = self.Rescale("G", X, scale)
        self.stamps["I"] = self.Rescale("I", X, scale)

        self.EnhanceImage()

        # Create PNG image
        rgbArray = numpy.zeros((self.nrow, self.ncol, 3), 'uint8')
        rgbArray[..., 0] = self.stamps["I"]
        rgbArray[..., 1] = self.stamps["R"]
        rgbArray[..., 2] = self.stamps["G"]
        im = Image.fromarray(numpy.flipud(rgbArray))

        # Write Metadata to Image
        meta = PngImagePlugin.PngInfo()
        meta.add_text("crval1", str(self.crval1))
        meta.add_text("crval2", str(self.crval2))
        meta.add_text("crpix1", str(self.crpix1))
        meta.add_text("crpix2", str(self.crpix2))
        meta.add_text("cd1_1", str(self.cd1_1))
        meta.add_text("cd1_2", str(self.cd1_2))
        meta.add_text("cd2_1", str(self.cd2_1))
        meta.add_text("cd2_2", str(self.cd2_2))
        meta.add_text("copyright", "nord nord@fnal.gov")
        reserved = ('interlace', 'gamma', 'dpi', 'transparency', 'aspect')

        self.MakeOutputFileName()
       #  print "output: ", self.outfile

        f = open(self.outfile, "wc")

        # copy metadata into new object
        for k, v in im.info.iteritems():
            if k in reserved:
                continue
            meta.add_text(k, v, 0)

        # Save Image to file
        im.save(self.outfile, format="png")  # ,  pnginfo=meta)
        f.close()

        time_stop = time.time()
        self.make_image_time = time_stop - time_start


def test():

    dir_input = "/Users/nord/Projects/LensPop/SimImages/1/"
    filenameG = "image_g_SDSS.fits"
    filenameR = "image_r_SDSS.fits"
    filenameI = "image_i_SDSS.fits"

    image = Colorize()
    image.read_data_files(dir_input, filenameG, filenameR, filenameI)
    image.ProcessFile()
