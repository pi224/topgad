import sys
import SimLens as sl
import pprint
import os
import numpy as np

pp = pprint.PrettyPrinter(indent=4)

def demo_base():

    dir_output_base = "./ImagesNew/"
    dir_output_len = dir_output_base + "Lens/"
    dir_output_non = dir_output_base + "Non/"

    # make directory
    if not os.path.isdir(dir_output_len):
        os.mkdir(dir_output_len)
    if not os.path.isdir(dir_output_non):
        os.mkdir(dir_output_non)

    # create object
    sim = sl.SimLens()

    # generate lens pars
    lens_class = False
    Nobject = 10
    params = sim.generate_lenspars_params(Nobject, 0.5, 1.0, lens_class)
    lenspars_set = sim.generate_lenspars_set(params, lens_class)
    myfile = "./data/lenspars_set_non.pkl"
    sim.save_lenspars(myfile, lenspars_set)

    # print "Lenspars Set"
    # pp.pprint(lenspars_set[0])

    # generate lens image sample
    data, labels = sim.generate_lens_sample(lenspars_set,
                                            lens_class=lens_class,
                                            save_color_image=True)

    sim.save_data(data, labels)


def demo_training(run_number, psf_fac, exp_fac, Nobject=100):

    sim = sl.SimLens()

    # calculate pixel value
    Nside_pix = 64

    # generate lens pars
    # seed2 = 914125
    seed1 = 827282
    seed = seed1
    # psf_fac = 0.5
    # Nobject=10000
    brange = [0.1, 5.]
    xsrange = [-2.5, 2.5]
    ysrange = [-2.5, 2.5]

    # check the position of the sources for efficient lens generation
    sim.check_source_position_limits(xsrange, ysrange, Nside_pix)

    # generate run path
    # run_path = sim.generate_run_path("./data/", run_number, overwrite=True)
    directory = "/Users/nord/DataShare/Dropbox/irshad2brian/data/Simulation/SimLens/SimLensPop/"
    run_path = sim.generate_run_path(directory, run_number, overwrite=True)

    data, labels = sim.generate_training_sample(Nobject, Nobject,
                                                0.5, 1.0,
                                                run_number,
                                                seed=seed,
                                                psf_fac=psf_fac,
                                                exp_fac=exp_fac,
                                                Nside_pix=Nside_pix,
                                                brange=brange,
                                                xsrange=xsrange,
                                                ysrange=ysrange,
                                                run_path=run_path)
    sim.save_data(data, labels, run_path=run_path)


def demo_population():

    pop = sl.SimLensPopulation()
    run_number = 7
    mag_limit_lens = 23.
    mag_limit_src = 25.5
    Nb_lens_requested = 10000
    Nb_nons_requested = 10000
    survey = "DESc"
    run_path = pop.generate_run_path("./data/", run_number,
                                     overwrite=True)
    data, labels = pop.generate_pop_training_sample(Nb_lens_requested,
                                                    Nb_nons_requested,
                                                    mag_limit_lens=mag_limit_lens,
                                                    mag_limit_src=mag_limit_src, 
                                                    run_path=run_path,
                                                    survey=survey,
                                                    verbose_object=True)
    pop.save_data(data, labels, run_path=run_path)


def run_psf_list():
    psf_fac_list = np.arange(0.1, 2.1, 0.2)
    run_number = 13
    for psf_fac in psf_fac_list:
        #demo_training(run_number, psf_fac, 1.0)
        print psf_fac
        run_number += 1


def run_exp_list():
    # exp_fac_list = np.arange(0.2, 2.2, 0.2)
    exp_fac_list = np.arange(2.0, 2.2, 0.2)
    run_number = 43
    Nobject = 2000
    for exp_fac in exp_fac_list:
        print "exp_fac:", exp_fac
        demo_training(run_number, 1.0, exp_fac, Nobject=Nobject)
        run_number += 1


<<<<<<< HEAD
demo_training(run_number='051', psf_fac=0.1, exp_fac=1.0)
=======
# demo_training(run_number='034', psf_fac=1.0, exp_fac=1.0)
>>>>>>> 405fad88fb41a680445e8816589d49048f2cab62
# demo_training()
# demo_base()
# demo_population()


# run_psf_list()
run_exp_list()