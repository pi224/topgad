class SimLensPopulation(SimLens):
    """
    """
    def generate_population_sample(self, Nb_requested,
                                   dir_data, lens_class, run_path,
                                   mag_limit_lens=22.,
                                   mag_limit_src=25.,
                                   verbose_object=False,
                                   survey="Custom"):
        """generate full population data set"""
        # get file names
        path_tmp, files_tmp, nb_files = self.get_file_info(dir_data)

        # check if there are any files
        if nb_files < 1:
            print "ain't no files"
            sys.exit()

        # loop over directory
        data = None
        labels = None
        for file_tmp, i in zip(files_tmp, range(nb_files)):

            # read file
            lenspars_set = self.read_lenspars(path_tmp + file_tmp)

            nlens = len(lenspars_set)
            if nlens > 0:
                data_tmp, labels_tmp, ids_tmp = \
                    self.generate_lens_sample(lenspars_set,
                                              lens_class=lens_class,
                                              mag_limit_lens=mag_limit_lens,
                                              mag_limit_src=mag_limit_src,
                                              run_path=run_path,
                                              verbose_object=verbose_object,
                                              survey=survey,
                                              save_color_image=True)

                # concatenate data arrays
                if data_tmp is not None:
                    if data is None:
                        data = data_tmp
                        labels = labels_tmp
                    else:
                        data = np.concatenate((data, data_tmp))
                        labels = np.concatenate((labels, labels_tmp))

                if data is not None:
                    Ndata = len(data)

                    if Ndata >= Nb_requested:
                        return data, labels

                # if i == 10000:
                #    break

        return data, labels

    def generate_pop_training_sample(self,
                                     Nb_lens_requested,
                                     Nb_nons_requested,
                                     mag_limit_lens=22.,
                                     mag_limit_src=25.,
                                     run_path="./data/",
                                     survey="Custom",
                                     verbose_object=False):
        # run_number = 3
        shuffle = True

        # make direcotry names
        dir_base = run_path + "idealisedlenses/"

        # directory
        dir_lens = dir_base + "lens/"
        dir_nons = dir_base + "nons/"
        print dir_lens

        print "make lenses"
        data_lens, labels_lens = \
            self.generate_population_sample(Nb_lens_requested, dir_lens,
                                            True,
                                            run_path,
                                            mag_limit_lens=22.,
                                            mag_limit_src=25.,
                                            survey=survey,
                                            verbose_object=verbose_object)

        print "make non-lenses"
        data_nons, labels_nons = \
            self.generate_population_sample(Nb_nons_requested, dir_nons,
                                            False,
                                            run_path,
                                            mag_limit_lens=22.,
                                            mag_limit_src=25.,
                                            survey=survey,
                                            verbose_object=verbose_object)

        data = np.concatenate((data_lens, data_nons))
        labels = np.concatenate((labels_lens, labels_nons))

        # shuffle concatenated data
        if shuffle:
            Nlens = len(data_lens)
            Nnons = len(data_nons)
            Ntot = Nlens + Nnons
            print "shuffle arrays"
            arr = np.arange(Ntot)
            np.random.shuffle(arr)

            data = data[arr]
            labels = labels[arr]

        return data, labels
