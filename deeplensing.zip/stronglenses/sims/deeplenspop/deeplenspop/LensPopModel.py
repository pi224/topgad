import os
import sys
# from astropy.io import fits
from FastLensSim import *
from ColorizeFunction import Colorize
import numpy as np


def GenerateLensParameters(zl, zs, be, xs, ys, Lenstype=True, **kwargs):
    """Set lens pars"""

    return lenspars


def GenerateLensSample(lenspars, i,
                       survey="Custom",
                       nsources=1,
                       SNcutA=1,
                       magcut=10,
                       SNcutBmin=0,
                       SNcutBmax=500,
                       Lenstype=True):
    """Generate lens sample based on survey parameters"""

    return SimSet


def SaveImages(SimSet,
               survey="Custom",
               folder="ImagesNew/",
               outfile="test.png"):
    """Save Images"""

    return 


def GenerateLens(params, dir_output, Lenstype=True, **kwargs):

    return data, labels, metadata_lenspars


def SaveDataArrays(data, labels, metadata, dir_output):
    """Save Data arrays"""


def demo():
    """Demo/run script"""
    dir_output_base = "./ImagesNew/"
    dir_output_len = dir_output_base + "Lens/"
    dir_output_non = dir_output_base + "Non/"

    # make directory
    if not os.path.isdir(dir_output_len):
        os.mkdir(dir_output_len)
    if not os.path.isdir(dir_output_non):
        os.mkdir(dir_output_non)

    #xsmin,dxs = 1., 1.
    xsmin,dxs = 0.1, 0.1
    xsmax = xsmin + dxs
    zlrange = np.arange(1.0, 2.0, 1.0)
    zsrange = np.arange(2.0, 4.0, 1.0)
    berange = np.arange(1.0, 3.0, 1.0)
    xsrange = np.arange(xsmin, xsmax, dxs)
    ysrange = np.arange(xsmin, xsmax, dxs)
    #ysrange = np.arange(.10, .20, .10)

    params = [[zl, zs, be, xs, ys]
              for zl in zlrange
              for zs in zsrange
              for be in berange
              for xs in xsrange
              for ys in ysrange]

    metadata_lenspop = {
        "zlrange": zlrange,
        "zsrange": zsrange,
        "berange": berange,
        "xsrange": xsrange,
        "ysrange": ysrange
    }

    np.save(dir_output_base + 'metadata_lenspop.npy', metadata_lenspop)

    dataset_len = GenerateLens(params, dir_output_len, Lenstype=True)
    #dataset_non = GenerateLens(params, dir_output_non, Lenstype=False)

    '''
    data_len, labels_len, metadata_len = dataset_len
    data_non, labels_non, metadata_non = dataset_non

    # join tables
    data_tot = np.concatenate((data_len, data_non))
    labels_tot = np.concatenate((labels_len, labels_non))
    metadata_tot = np.concatenate((metadata_len, metadata_non))

    # save tables
    SaveDataArrays(data_tot, labels_tot, metadata_tot, dir_output_base)
    '''

# set noise level, psf amount. What other common features might you expect
# how to add discrete types of noise to images: foregroudn objects, edge effects, stars, etc.
# goals: find new lenses in some data sets

# find out what the rest of the parameters are
# how much code do we need to run this? can we get rid of a bunch of files
# define some questions; get some plots for paper
# in the LensPop directory?


demo()
