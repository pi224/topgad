import os
import pprint
import sys
from FastLensSim import *
from ColorizeFunction import Colorize
import numpy as np
import cPickle


class SimLens(object):
    """
    """

    def __init__(self):
        self.xblah = 0.

    def read_pickle(self, myfile):
        """read pickle file"""
        myf = open(myfile, 'rb')
        data = cPickle.load(myf)
        myf.close()
        return data

    def save_pickle(self, myfile, data):
        """save data to file"""
        myf = open(myfile, 'wb')
        cPickle.dump(data, myf)
        myf.close()
        return

    def generate_lens_image(self, lenspars, i,
                            survey="Custom",
                            nsources=1,
                            SNcutA=1,
                            magcut=10,
                            SNcutBmin=0,
                            SNcutBmax=500,
                            lens_label=True):
        """generate image data for one lens or non-lens"""

        # Create Survey Simulation set
        SimSet = FastLensSim(survey)    # 
        SimSet.bfac = float(2)          #
        SimSet.rfac = float(2)          #
        print 'myimage', SimSet.image

        # visi5le magnitude value
        lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                                 lenspars["rl"]["i_SDSS"] +
                                 lenspars["rl"]["z_SDSS"]) / 3
        lenspars["mag"] = {}
        lenspars["msrc"] = {}
        lenspars["mag"] = {}
        lenspars["msrc"] = {}
        lenspars["SN"] = {}
        lenspars["bestband"] = {}
        lenspars["pf"] = {}
        lenspars["resolved"] = {}
        lenspars["poptag"] = {}
        lenspars["seeing"] = {}
        lenspars["rfpf"] = {}
        lenspars["rfsn"] = {}

        # mi in ml
        for mi in [lenspars["ml"], lenspars["ms"][1]]:
            mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

        # print "\t ... set lens pars"
        SimSet.setLensPars(lenspars["ml"],
                           lenspars["rl"],
                           lenspars["ql"],
                           reset=True)

        # set source parameters
        for j in range(nsources):
            jj = j + 1
            SimSet.setSourcePars(lenspars["b"][jj],
                                 lenspars["ms"][jj],
                                 lenspars["xs"][jj],
                                 lenspars["ys"][jj],
                                 lenspars["qs"][jj],
                                 lenspars["ps"][jj],
                                 lenspars["rs"][jj],
                                 sourcenumber=jj)

        # print "\t ... not last survey"
        SimSet.makeLens(stochasticmode="MP")
        SOdraw = numpy.array(SimSet.SOdraw)

        # print "simset images a", len(SimSet.image)

        # for key, value in SimSet.seeing.iteritems():
        #    SimSet.seeing[key] = 5.0

        # print "\t ... get meta data"
        print 'myimage 1', SimSet.image
        mag, msrc, SN, bestband, pf = \
            SimSet.SourceMetaData(SNcutA=SNcutA, magcut=magcut,
                                  SNcutB=[SNcutBmin, SNcutBmax])
        print 'myimage 2', SimSet.image

        # print "simset images b", len(SimSet.image)

        # create some lenspars elements
        lenspars["SN"][survey] = {}
        lenspars["bestband"][survey] = {}
        lenspars["pf"][survey] = {}
        lenspars["resolved"][survey] = {}
        lenspars["poptag"][survey] = i
        lenspars["seeing"][survey] = SimSet.seeing

        # print "\t ... Sources: ", SimSet.sourcenumbers
        rfpf = {}
        rfsn = {}
        for src in SimSet.sourcenumbers:
            rfpf[src] = False
            rfsn[src] = [0]
            lenspars["mag"][src] = mag[src]
            lenspars["msrc"][src] = msrc[src]
            lenspars["SN"][survey][src] = SN[src]
            lenspars["bestband"][survey][src] = bestband[src]
            lenspars["pf"][survey][src] = pf[src]
            lenspars["resolved"][survey][src] = SimSet.resolved[src]

        # print "\t ... ... make lens"
        # print "\t set lens pars"
        SimSet.makeLens(noisy=True,
                        stochasticmode="1P",
                        SOdraw=SOdraw,
                        MakeModel=False)
        print 'myimage 3', SimSet.image

        # print "simset images c", len(SimSet.image)

        lenspars["rfpf"][survey] = rfpf
        lenspars["rfsn"][survey] = rfsn

        return SimSet

    def generate_lenspars(self, zl, zs, be, xs, ys, lens_label):
        """Set lens pars"""

        '''
        lenspars = {
            'zl': 1.0,
            'zs': {1: 1.5},
            'ps': {1: 90.0},
            'qs': {1: 0.19031817426687943},
            'b': {1: 5.},
            'lens?': True,
            'rs': {1: 0.11273429289548288},
            'ml': {
                'g_SDSS': 25.764342164961832,
                'r_SDSS': 22.918909056282573,
                'i_SDSS': 21.669371051501813,
                'z_SDSS': 20.353736610804404,
                'F814W_ACS': 21.008432268442618,
                'Y_UKIRT': 19.78383167424828
            },
            'sigl': 391.03020182762191,
            'mhalo': {1: 0.46039999999999998},
            'ms': {1: {
                'g_SDSS': 23.38,
                'r_SDSS': 23.60,
                'i_SDSS': 23.58,
                'z_SDSS': 23.55,
                'F814W_ACS': 21.58,
                'Y_UKIRT': 2128.5093999999999
            }},
            'rl': {
                'g_SDSS': 0.47511297207625075,
                'r_SDSS': 0.47511297207625075,
                'i_SDSS': 0.47511297207625075,
                'z_SDSS': 0.47511297207625075,
                'F814W_ACS': 0.47511297207625075,
                'Y_UKIRT': 0.47511297207625075
            },
            'xs': {1: 105.3146192669123881},
            'ys': {1: 105.3029063512358129409},
            'mstar': {1: 20.397600000000001},
            'ql': 0.61276676378304762
        }

        lenspars = {
            'b': {1: 0.64556853558189777},
            'lens?': True,
            'mhalo': {1: 0.10539999999999999},
            'ml': {'F814W_ACS': 21.983378610049847,
                   'Y_UKIRT': 21.090647325921669,
                   'g_SDSS': 26.151242946930644,
                   'i_SDSS': 22.395153074240355,
                   'r_SDSS': 23.8571041448789,
                   'z_SDSS': 21.561114891443776},
            'ms': {1: {'F814W_ACS': 23.995200000000001,
                       'Y_UKIRT': 2375.4155999999998,
                       'g_SDSS': 23.543299999999999,
                       'i_SDSS': 22.995200000000001,
                       'r_SDSS': 23.026499999999999,
                       'z_SDSS': 23.0244}},
            'mstar': {1: 9.6394000000000002},
            'ps': {1: 143.50649280415229},
            'ql': 0.83017202880494501,
            'qs': {1: 0.29399054698465366},
            'rl': {'F814W_ACS': 0.43112935432779748,
                   'Y_UKIRT': 0.43112935432779748,
                   'g_SDSS': 0.43112935432779748,
                   'i_SDSS': 0.43112935432779748,
                   'r_SDSS': 0.43112935432779748,
                   'z_SDSS': 0.43112935432779748},
            'rs': {1: 0.058848950387115274},
            'sigl': 315.30122314360003,
            'xs': {1: 0.1414747081111444},
            'ys': {1: 0.43135313860155838},
            'zl': 0.76108273925537995,
            'zs': {1: 1.7244999999999999}
        }
        '''

        lenspars = {
            'b': {1: 0.54513253816083274},
            'lens?': True,
            'mhalo': {1: 1.6625000000000001},
            'ml': {'F814W_ACS': 19.816901257087427,
                   'Y_UKIRT': 19.300810290924737,
                   'g_SDSS': 22.790398139331415,
                   'i_SDSS': 20.037092590366445,
                   'r_SDSS': 20.877342250858973,
                   'z_SDSS': 19.545814170477414},
            'ms': {1: {'F814W_ACS': 25.061,
                       'Y_UKIRT': 2399.8292999999999,
                       'g_SDSS': 27.340599999999998,
                       'i_SDSS': 25.061,
                       'r_SDSS': 26.0425,
                       'z_SDSS': 24.2407}},
            'mstar': {1: 3.5287000000000002},
            'ps': {1: 158.96451925444103},
            'ql': 0.6436341725147261,
            'qs': {1: 0.84749127186445616},
            'rl': {'F814W_ACS': 0.40287687506453845,
                   'Y_UKIRT': 0.40287687506453845,
                   'g_SDSS': 0.40287687506453845,
                   'i_SDSS': 0.40287687506453845,
                   'r_SDSS': 0.40287687506453845,
                   'z_SDSS': 0.40287687506453845},
            'rs': {1: 0.54520596569448676},
            'sigl': 185.48431996635338,
            'xs': {1: -0.04787559871448411},
            'ys': {1: 0.06047856328652663},
            'zl': 0.44074644427617343,
            'zs': {1: 1.1954}
        }

        """
        lenspars['xs'][1] = xs
        lenspars['ys'][1] = ys
        lenspars['b'][1] = be
        lenspars['zl'] = zl
        lenspars['zs'][1] = zs
        if lens_label == 0:
            lens_label_bool = False
        elif lens_label == 1:
            lens_label_bool = True
        lenspars['lens?'] = lens_label_bool

        # if lens_label_bool is False:
        #    for key, value in lenspars['ms'][1].iteritems():
        #        lenspars['ms'][1][key] = 99.
        """

        return lenspars

    def generate_lenspars_set(self, params, lens_label):
        """ generate sample of lenspars """

        lenspars_set = {}
        for i, param in zip(range(len(params)), params):

            [zl, zs, be, xs, ys] = param
            lenspars = self.generate_lenspars(zl, zs, be, xs, ys, lens_label)
            lenspars_set[i] = lenspars

        return lenspars_set

    def generate_lenspars_params(self):
        """ generate sample of lenspars """

        xsmin, dxs = 1.0, 1.0
        xsmax = xsmin + dxs
        zlrange = np.arange(1.0, 2.0, 1.0)
        zsrange = np.arange(2.0, 3.0, 1.0)
        berange = np.arange(1.1, 1.2, 0.1)
        xsrange = np.arange(xsmin, xsmax, dxs)
        ysrange = np.arange(xsmin, xsmax, dxs)

        params = [[zli, zsi, bei, xsi, ysi]
                  for zli in zlrange
                  for zsi in zsrange
                  for bei in berange
                  for xsi in xsrange
                  for ysi in ysrange]

        return params

    def generate_lens_sample(self, lenspars_set, lens_label,
                             save_color_image=False):
        """generate sample of lenses from set of lenspars"""

        # for i, lenspars in zip(range(len(lenspars_set)), lenspars_set):
        data = []
        Ndata = len(lenspars_set)
        for i, lenspars in lenspars_set.iteritems():
            SimSet = self.generate_lens_image(lenspars, i,
                                              survey="Custom",
                                              nsources=1,
                                              SNcutA=10,
                                              magcut=10,
                                              SNcutBmin=2000,
                                              SNcutBmax=2000,
                                              lens_label=lens_label)

            # img = np.ndarray((Nchannel, Nside, Nside))
            img_set = SimSet.image
            img = [y for x, y in img_set.iteritems()]
            data.append(img)

            # save color image
            if save_color_image:
                outfile = "test_" + str(i).zfill(4) + ".png"

                self.save_image(img,
                                survey="lssta",
                                folder="ImagesNew/",
                                outfile=outfile)

            print "object: " + str(i + 1).zfill(4) +\
                " / " + str(Ndata).zfill(4)

        # make the data an array
        data = np.array(data)

        return data

    def generate_labels(self, Ndata, lens_label):
        """generate labels for class of objects"""

        labels = np.ones(Ndata, dtype=int) * lens_label

        return labels

    def save_image(self, img_set,
                   survey="Custom",
                   folder="ImagesNew/",
                   outfile="test.png"):
        """Save Images"""

        # make directory
        if not os.path.isdir(folder):
            os.mkdir(folder)

        # print "\t ... my folder", folder
        myimage = Colorize(dir_output=folder, outfile=outfile)
        for img, band_color in zip(img_set, ["G", "R", "I"]):
            print "img", img
            myimage.read_data_object(band_color, img_set)
        myimage.ProcessFile()

        return

    def save_data(data, labels, metadata, dir_output):
        """Save Data arrays"""
        np.save(dir_output + 'xtrain.npy', data)
        np.save(dir_output + 'ytrain.npy', labels)
        np.save(dir_output + 'metadata_lens.npy', metadata)


def demo():

    pp = pprint.PrettyPrinter(indent=4)

    dir_output_base = "./ImagesNew/"
    dir_output_len = dir_output_base + "Lens/"
    dir_output_non = dir_output_base + "Non/"

    # make directory
    if not os.path.isdir(dir_output_len):
        os.mkdir(dir_output_len)
    if not os.path.isdir(dir_output_non):
        os.mkdir(dir_output_non)

    # create object
    myobj = SimLens()

    # generate lens pars
    params = myobj.generate_lenspars_params()
    lens_label = 1
    lenspars_set = myobj.generate_lenspars_set(params, lens_label)
    pp.pprint(lenspars_set[0])

    # myfile = "test" + str(lens_label) + ".pkl"
    # myobj.save_pickle(myfile, lenspars_set)
    # pp.pprint(lenspars_set)

    # read population data
    # myfile = "idealisedlenses/nonlenspopulation_lsst.pkl"
    # lenspars_set = myobj.read_pickle(myfile)

    # generate lens image sample
    data = myobj.generate_lens_sample(lenspars_set,
                                      lens_label=lens_label,
                                      save_color_image=True)

    print data

demo()
