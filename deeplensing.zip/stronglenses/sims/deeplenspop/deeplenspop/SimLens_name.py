import os
import pprint
import sys
from FastLensSim import *
from ColorizeFunction import Colorize

# logging
import logging.config
import numpy as np
import cPickle

pp = pprint.PrettyPrinter(indent=4)


# --------------------------------------------------------------------
# --------------------------------------------------------------------
# I/O
# --------------------------------------------------------------------
# --------------------------------------------------------------------
# ------------------------------------------------------------------------------
def load_pickle(directory, file_type):
    """Read pickle file."""
    file_type_dictionary = {
                            "lenspars": "lenspars.pkl"
                            }
    # create file aname
    f_io = directory + file_type_dictionary[file_type]

    # check if file exists
    exists = check_file_exists(f_io)

    # load or not, according to exists
    if exists:
        f = open(f_io, 'rb')
        data = cPickle.load(f)
        f.close()
    else:
        log.warning("file does not exist: " + f_io)
    
    return data


# ------------------------------------------------------------------------------
def save_pickle(directory, file_type, data, overwrite=False):
    """Save pickle file."""
    file_type_dictionary = {
                            "lenspars": "lenspars.pkl",
                            "lenspars_set_lens": "lenspars_set_lens.pkl",
                            "lenspars_set_nons": "lenspars_set_nons.pkl"
                            }

    # make output directory if necessary
    make_dir(directory)

    # Create file name
    f_io = directory + file_type_dictionary[file_type]

    # check for overwrite permission
    clobber = check_overwrite(f_io, overwrite=overwrite)
    if clobber:
        f = open(f_io, 'wb')
        cPickle.dump(data, f)
        f.close()
    else:
        # print "did not write to file"
        log.warning("did not write to file")


# --------------------------------------------------------------------
def save_data(dir_data, data, labels):
    """Save Data arrays"""
    np.save(dir_data + "xtrain_lenspop.npy", data)
    np.save(dir_data + "ytrain_lenspop.npy", labels)


# --------------------------------------------------------------------
def save_image(SimSet,
               dir_output="./data/ImagesNew/",
               outfile="test.png",
               method="colorize"):
    """Save Images"""

    # make directory
    make_dir(dir_output)

    if method == "colorize":
        myimage = Colorize(dir_output=dir_output, outfile=outfile,
                           enhLevel=0.3,
                           Q=0.8,
                           Gcor=1.2,
                           Rcor=0.8,
                           Icor=1.0,
                           Alpha=0.06,
                           satCut=0.8)
        band_set = ["g_SDSS", "r_SDSS", "i_SDSS"]
        myimage.read_data_set(band_set, SimSet.image)
        myimage.ProcessFile()
    elif method == "colorimage":
        mydata = SimSet.makeColorLens()
        myshape = mydata.shape
        from PIL import Image
        rgbArray = np.zeros(myshape, 'uint8')
        rgbArray[..., 0] = mydata[:, :, 0] * 256
        rgbArray[..., 1] = mydata[:, :, 1] * 256
        rgbArray[..., 2] = mydata[:, :, 2] * 256
        img = Image.fromarray(rgbArray, 'RGB')
        img.save(dir_output + outfile)

    return


# --------------------------------------------------------------------
def get_file_info(dir_object):
    """get directory and file information"""
    print "dir object", dir_object
    path_tmp, dirs_tmp, files_tmp = os.walk(dir_object).next()
    nb_files = len(files_tmp)
    return path_tmp, files_tmp, nb_files


# --------------------------------------------------------------------
def prepare_directory(user, id_data):
    """Make data directories."""
    if user == "nord":
        user = "nord/DataShare"

    # ------------------------
    # set base data directory
    # ------------------------
    uname = os.uname()
    system_name = uname[1]
    log.info("Running on system: "+ system_name)
    if "des" in system_name:
        dir_system = "/data/des40.b/data/nord/"
    else:
        dir_system = "/Users/" + user 

    # data
    dir_base = dir_system + "/Dropbox/irshad2brian/"
    dir_data = dir_base + "data/"
    dir_data_full = "Run" + str(id_data_train).zfill(3) + "/"


    return run_path


# ------------------------------------------------------------------------------
def make_dir(dir):
    """Make Directories."""
    try:
        os.makedirs(dir)
    except OSError:
        if not os.path.isdir(dir):
            raise
    return 0


# ------------------------------------------------------------------------------
def check_file_exists(f_io, verbose=False):
    """Check if a file exists."""
    if os.path.isfile(f_io):
        exists = True
    else:
        exists = False
        if verbose: 
            # print "File does not exist: " + f_io
            log.warning("file does not exist: " + f_io)

    return exists


# ------------------------------------------------------------------------------
def check_overwrite(f_io, overwrite=False, verbose=False):
    """Check if we want overwrite."""
    exists = check_file_exists(f_io, verbose=verbose)

    if exists: 
        # if it exists ...
        if overwrite:
            # clobber  is true if allowed to overwrite
            # print "File exists. OVERWRITE: " + f_io 
            log.warning("File exists. OVERWRITE: " + f_io)
            clobber = True
        else:
            # print "File exists: DO NOT OVERWRITE" + f_io
            log.warning("File exists: DO NOT OVERWRITE" + f_io)
            clobber = False
    else:
        clobber = True

    return clobber


# --------------------------------------------------------------------
# --------------------------------------------------------------------
# Generate Lens Parameters
# --------------------------------------------------------------------
# --------------------------------------------------------------------
# --------------------------------------------------------------------
def generate_lenspars(zl, zs, be, xs, ys, lens_class):
    """Set lens pars"""

    # 'g_SDSS': 24.370519353475789,
    # 'i_SDSS': 20.992404985468962,
    # 'r_SDSS': 22.433858036695487,
    lenspars = {
        'b': {1: 1.50459557390608167},
        'lens?': True,
        'mhalo': {1: 0.58579999999999999},
        'ml': {'F814W_ACS': 23.700488839837011,
               'Y_UKIRT': 99.987330016400776,
               'z_SDSS': 23.384894670188533,
               'g_SDSS': 22.0,
               'r_SDSS': 21.6,
               'i_SDSS': 20.15},
        'ms': {1: {'F814W_ACS': 21.899000000000001,
                   'Y_UKIRT': 2145.7356,
                   'g_SDSS': 22.049399999999999,
                   'i_SDSS': 21.899000000000001,
                   'r_SDSS': 22.091000000000001,
                   'z_SDSS': 21.7044}},
        'mstar': {1: 24.700800000000001},
        'ps': {1: 112.89232455485484},
        'ql': 0.20065521218913041,
        'qs': {1: 0.59850689607147711},
        'rl': {'F814W_ACS': 0.58849609885759535,
               'Y_UKIRT': 0.58849609885759535,
               'g_SDSS': 0.58849609885759535,
               'i_SDSS': 0.58849609885759535,
               'r_SDSS': 0.58849609885759535,
               'z_SDSS': 0.58849609885759535},
        'rs': {1: 1.48655683444557},
        'sigl': 197.52337452393428,
        'xs': {1: 4.0},
        'ys': {1: 4.0},
        'zl': 0.64597976934717483,
        'zs': {1: 1.4413}
    }

    lenspars['xs'][1] = xs
    lenspars['ys'][1] = ys
    lenspars['b'][1] = be

    return lenspars


# --------------------------------------------------------------------
def generate_lenspars_set(params, lens_class):
    """ generate sample of lenspars """

    lenspars_set = {}
    for i, param in zip(range(len(params)), params):

        [zl, zs, be, xs, ys] = param
        lenspars = generate_lenspars(zl, zs, be, xs, ys, lens_class)
        lenspars_set[i] = lenspars

    return lenspars_set


# --------------------------------------------------------------------
def generate_lenspars_params(self,
                             Nobject, zl, zs, lens_class,
                             brange=[0.1, 2.0],
                             xsrange=[0.0, 7.0],
                             ysrange=[0.0, 9.0],
                             seed=827282):
    """ generate sample of lenspars """

    # set ranges
    bmin, bmax = brange[0], brange[1]
    xsmin, xsmax = xsrange[0], xsrange[1]
    ysmin, ysmax = ysrange[0], ysrange[1]

    # redshift lists
    zl_list = np.ones(Nobject) * zl
    zs_list = np.ones(Nobject) * zs

    # set lists
    b_list = []
    xs_list = []
    ys_list = []
    Nobject_have = 0
    np.random.seed(seed)
    while Nobject_have < Nobject:
        b_tmp = np.random.uniform(bmin, bmax)
        xs_tmp = np.random.uniform(xsmin, xsmax)
        ys_tmp = np.random.uniform(ysmin, ysmax)
        lens_status = check_lens_status(xs_tmp, ys_tmp,
                                             b_tmp, lens_class)
        if lens_status:
            b_list.append(b_tmp)
            xs_list.append(xs_tmp)
            ys_list.append(ys_tmp)
            Nobject_have = len(b_list)

    # convert to numpy arrays
    b_list = np.array(b_list)
    xs_list = np.array(xs_list)
    ys_list = np.array(ys_list)

    # store params
    params = [np.array([zli, zsi, bi, xsi, ysi])
              for zli, zsi, bi, xsi, ysi
              in zip(zl_list, zs_list, b_list, xs_list, ys_list)]

    params = np.array(params)

    return params


# --------------------------------------------------------------------
def check_lens_status(xs_tmp, ys_tmp, b_tmp, lens_class):
    """ check whether the object is a lens or not """

    # measure distance of source
    radius2 = xs_tmp**2 + ys_tmp**2
    radius = np.sqrt(radius2)

    # get boolean for within einstein radius
    within = bool(radius < b_tmp)

    # check if meets class
    if within is lens_class:
        return True
    else:
        return False



# --------------------------------------------------------------------
# --------------------------------------------------------------------
# Generate Lens Sample
# --------------------------------------------------------------------
# --------------------------------------------------------------------
# --------------------------------------------------------------------
def generate_lens(lenspars, lens_class,
                        survey="Custom",
                        psf_fac=1.0,
                        exp_fac=1.0,
                        Nside_pix=32
                        ):
    """generate image data for one lens or non-lens"""
    # survey = "Custom"
    nsources = 1
    SNcutA = 10
    magcut = 0
    SNcutBmin = 0
    SNcutBmax = 0
    myfloor = 999
    # exp_fac = 1.0

    # Create Survey Simulation set
    SimSet = FastLensSim(survey, Nside_pix=Nside_pix)
    SimSet.bfac = float(100000)  # high allows object to always be observed
    SimSet.rfac = float(0)     # low allows object to always be observed
    SimSet.exposuretimes['g_SDSS'] *= exp_fac
    SimSet.exposuretimes['r_SDSS'] *= exp_fac
    SimSet.exposuretimes['i_SDSS'] *= exp_fac

    # visible magnitude value
    lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                             lenspars["rl"]["i_SDSS"] +
                             lenspars["rl"]["z_SDSS"]) / 3

    # mi in ml
    for mi in [lenspars["ml"], lenspars["ms"][1]]:
        mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["SN"] = {}
    lenspars["bestband"] = {}
    lenspars["pf"] = {}
    lenspars["resolved"] = {}
    lenspars["poptag"] = {}
    lenspars["seeing"] = {}
    lenspars["rfpf"] = {}
    lenspars["rfsn"] = {}

    SimSet.setLensPars(lenspars["ml"],
                       lenspars["rl"],
                       lenspars["ql"],
                       reset=True)

    # set source parameters
    for j in range(nsources):
        jj = j + 1
        SimSet.setSourcePars(lenspars["b"][jj],
                             lenspars["ms"][jj],
                             lenspars["xs"][jj],
                             lenspars["ys"][jj],
                             lenspars["qs"][jj],
                             lenspars["ps"][jj],
                             lenspars["rs"][jj],
                             sourcenumber=jj)
    if verbose_debug:
        print "len pre", len(SimSet.image)
    SimSet.makeLens(stochasticmode="MP",
                    musthaveallbands=True,
                    psf_fac=psf_fac,
                    myfloor=myfloor)
    SOdraw = numpy.array(SimSet.SOdraw)
    if verbose_debug:
        print "len primary", len(SimSet.image)

    mag, msrc, SN, bestband, pf = \
        SimSet.SourceMetaData(SNcutA=SNcutA,
                              magcut=magcut,
                              SNcutB=[SNcutBmin, SNcutBmax])

    # create some lenspars elements
    lenspars["SN"][survey] = {}
    lenspars["bestband"][survey] = {}
    lenspars["pf"][survey] = {}
    lenspars["resolved"][survey] = {}
    lenspars["seeing"][survey] = SimSet.seeing

    rfpf = {}
    rfsn = {}
    for src in SimSet.sourcenumbers:
        rfpf[src] = False
        rfsn[src] = [0]
        lenspars["mag"][src] = mag[src]
        lenspars["msrc"][src] = msrc[src]
        lenspars["SN"][survey][src] = SN[src]
        lenspars["bestband"][survey][src] = bestband[src]
        lenspars["pf"][survey][src] = pf[src]
        lenspars["resolved"][survey][src] = SimSet.resolved[src]

    if verbose_debug:
        print "len secondary", len(SimSet.image)

    SimSet.makeLens(noisy=True,
                    stochasticmode="MP",
                    SOdraw=SOdraw,
                    musthaveallbands=True,
                    MakeModel=True,
                    psf_fac=psf_fac,
                    myfloor=myfloor)

    lenspars["rfpf"][survey] = rfpf
    lenspars["rfsn"][survey] = rfsn

    return SimSet

# --------------------------------------------------------------------
def generate_system_parameters(Nobject, system_params):
    params_lens = generate_lenspars_params(Nlens, zl, zs, True,
                                                seed=seed,
                                                brange=brange,
                                                xsrange=xsrange,
                                                ysrange=ysrange)
    lenspars_set_lens = generate_lenspars_set(params_lens, True)

    return lenspars_set_lens

# --------------------------------------------------------------------
def generate_training_sample(self,
                             Nlens, Nnons, zl, zs,
                             run_number,
                             psf_fac=1.0,
                             exp_fac=1.0,
                             Nside_pix=32,
                             brange=[0.1, 2.0],
                             xsrange=[0.0, 7.0],
                             ysrange=[0.0, 9.0],
                             seed=827282,
                             shuffle=True,
                             save_lenspars=True,
                             survey="Custom",
                             run_path="./data/"):
    """ generate full training sample of both lenses and non-lenses"""

    verbose_object = True
    save_color_image = True

    # generate lens pars
    log.info("generate lensparsets")
    lenspars_set_lens = generate_system_parameters(Nlens, system_params)
    nonspars_set_nons = generate_system_parameters(Nnons, system_params)

    log.info("save lensparsets to file")
    save_pickle(dirs["data"], lenspars_set_lens)
    save_pickle(dirs["data"], lenspars_set_nons)

    # generate lens image sample
    log.info("generate lens sample")
    data_lens, labels_lens, ids_lens = \
        generate_lens_sample(lenspars_set_lens, lens_class=True,
                                  save_color_image=save_color_image,
                                  run_path=run_path,
                                  survey=survey,
                                  psf_fac=psf_fac,
                                  exp_fac=exp_fac,
                                  Nside_pix=Nside_pix,
                                  verbose_object=verbose_object)

    log.info("generate non lens sample")
    data_nons, labels_nons, ids_nons = \
        generate_lens_sample(lenspars_set_nons, lens_class=False,
                                  save_color_image=save_color_image,
                                  run_path=run_path,
                                  survey=survey,
                                  psf_fac=psf_fac,
                                  exp_fac=exp_fac,
                                  Nside_pix=Nside_pix,
                                  verbose_object=verbose_object)

    # concatenate data arrays
    log.info("concatenate arrays")
    data = np.concatenate((data_lens, data_nons))
    labels = np.concatenate((labels_lens, labels_nons))
    ids = np.concatenate((ids_lens, ids_nons))

    # shuffle concatenated data
    if shuffle:
        log.info("shuffle arrays")
        index_array = np.arange(Nlens + Nnons)
        np.random.shuffle(index_array)

        data = data[arr]
        labels = labels[arr]
        ids = ids[ids]

    return data, labels, ids



# --------------------------------------------------------------------
def check_seeing(seeing):
    see_sum = np.sum([see for k, see in seeing.iteritems()])
    if see_sum > 0.:
        pass_seeing = True
    elif see_sum == 0.:
        pass_seeing = False
    return pass_seeing


# --------------------------------------------------------------------
def check_photom(lenspars,
                 mag_limit=22,
                 band_list=['g_SDSS', 'r_SDSS', "i_SDSS"],
                 pass_dict={0: False, 1: False, 2: False, 3: True},
                 mag_type="lens"):
    """check photometric magnitudes for passing a cut"""
    if mag_type == "lens":
        photom = lenspars["ml"]
    elif mag_type == "src":
        photom = lenspars['ms'][1]

    # photom = lenspars['ml']
    mag_list = np.array([mag
                        for label, mag in photom.iteritems()
                        if label in band_list])
    check_limit = len(np.where(mag_list < mag_limit)[0])
    pass_photom = pass_dict[check_limit]
    # print mag_limit, check_limit
    # print mag_list, pass_photom

    return pass_photom


# --------------------------------------------------------------------
def check_photom_src(lenspars, mag_limit=22):
    # see_sum = np.sum([see for k, see in seeing.iteritems()])
    photom = lenspars['ms'][1]
    band_list = ['g_SDSS', 'r_SDSS', "i_SDSS"]
    count_pass = 0
    for label, mag in photom.iteritems():
        if label in band_list:
            if mag < mag_limit:
                count_pass += 1

    if count_pass >= len(band_list):
        pass_photom = True
    else:
        pass_photom = False

    return pass_photom


# --------------------------------------------------------------------
def generate_lens_sample(self,
                         lenspars_set,
                         lens_class,
                         mag_limit_lens=22.,
                         mag_limit_src=25.,
                         psf_fac=1.0,
                         exp_fac=1.0,
                         Nside_pix=32,
                         save_color_image=False,
                         run_path="./data/",
                         verbose_object=False,
                         survey="Custom"):
    """generate sample of lenses from set of lenspars"""

    # define name tag dictionary
    if save_image:
        class_dict = {True: "lens", False: "nons" }
        for k,v in class_dict.iteritems():
            make_dir(run_path + v + "/")


    Ndata = len(lenspars_set)
    data = []
    ids = []
    count_lens = 0
    for id_system, lenspars in lenspars_set.iteritems():

        # simulate lens
        SimSet = generate_lens(lenspars, lens_class,
                                          psf_fac=psf_fac,
                                          exp_fac=exp_fac,
                                          Nside_pix=Nside_pix,
                                          survey=survey)

        # create array format for output
        img = [y for x, y in SimSet.image.iteritems()]

        # append data on system
        data.append(img)
        ids.append(id_system)

        # increment count of systems
        count_lens += 1

        # save color image
        if save_color_image:
            name_tag = class_dict[lens_class]
            dir_output = run_path + name_tag + "/"
            outfile = "img_" + name_tag + "_" + str(i).zfill(5) + ".png"

            save_image(SimSet, dir_output=dir_output, outfile=outfile)

        if verbose_object:
            log.info("object: " + str(i + 1).zfill(4) +\
                " / " + str(Ndata).zfill(4) + "     " + str(count_lens))

        if verbose_debug:
            print 'object', i, lens_class, len(SimSet.image)
            print
            print
            print

    # make the data an array
    data = np.array(data)
    Ndata = len(data)

    # make labels
    labels = generate_labels(Ndata, lens_class)

    # make the id values an array
    ids = np.array(ids)

    if Ndata == 0:
        data = None
        labels = None

    return data, labels, ids


# --------------------------------------------------------------------
def generate_labels(Ndata, lens_class):
    """generate labels for class of objects"""

    labels = np.ones(Ndata, dtype=int) * lens_class

    return labels


# --------------------------------------------------------------------
def check_source_position_limits(xsrange, ysrange, Nside_pix):
    """Check if the source position maximum value is
    beyond the range of having
    an efficient placement of sources"""

    Nside_sec = Nside_pix * 0.263
    print "nside sec", Nside_sec
    Nside_sec_half = Nside_sec / 2.

    xmax_abs = max([abs(xs) for xs in xsrange])
    ymax_abs = max([abs(ys) for ys in ysrange])
    rmax = np.sqrt(xmax_abs**2 + ymax_abs**2)
    if rmax > Nside_sec_half:
        print "Limits on position ranges create non-lenses inefficiently"
        print "your radius", rmax
        print " max advisable radius", Nside_sec_half
        sys.exit()


# --------------------------------------------------------------------
def generate_population_sample(Nb_requested,
                               dir_data, lens_class, run_path,
                               mag_limit_lens=22.,
                               mag_limit_src=25.,
                               verbose_object=False,
                               survey="Custom"):
    """generate full population data set"""

    # get file names
    path_tmp, files_tmp, nb_files = get_file_info(dir_data)

    # check if there are any files
    if nb_files < 1:
        print "ain't no files"
        sys.exit()

    # loop over directory
    data = None
    labels = None
    for file_tmp, i in zip(files_tmp, range(nb_files)):

        # read file
        lenspars_set = load_pickle(path_tmp, )

        nlens = len(lenspars_set)
        if nlens > 0:
            data_tmp, labels_tmp, ids_tmp = \
                generate_lens_sample(lenspars_set,
                                          lens_class=lens_class,
                                          mag_limit_lens=mag_limit_lens,
                                          mag_limit_src=mag_limit_src,
                                          run_path=run_path,
                                          verbose_object=verbose_object,
                                          survey=survey,
                                          save_color_image=True)

            # concatenate data arrays
            if data_tmp is not None:
                if data is None:
                    data = data_tmp
                    labels = labels_tmp
                else:
                    data = np.concatenate((data, data_tmp))
                    labels = np.concatenate((labels, labels_tmp))

            if data is not None:
                Ndata = len(data)

                if Ndata >= Nb_requested:
                    return data, labels

            # if i == 10000:
            #    break

    return data, labels

def generate_pop_training_sample(self,
                                 Nb_lens_requested,
                                 Nb_nons_requested,
                                 mag_limit_lens=22.,
                                 mag_limit_src=25.,
                                 run_path="./data/",
                                 survey="Custom",
                                 verbose_object=False):
    # run_number = 3
    shuffle = True

    # make direcotry names
    dir_base = run_path + "idealisedlenses/"

    # directory
    dir_lens = dir_base + "lens/"
    dir_nons = dir_base + "nons/"
    print dir_lens

    print "make lenses"
    data_lens, labels_lens = \
        generate_population_sample(Nb_lens_requested, dir_lens,
                                        True,
                                        run_path,
                                        mag_limit_lens=22.,
                                        mag_limit_src=25.,
                                        survey=survey,
                                        verbose_object=verbose_object)

    print "make non-lenses"
    data_nons, labels_nons = \
        generate_population_sample(Nb_nons_requested, dir_nons,
                                        False,
                                        run_path,
                                        mag_limit_lens=22.,
                                        mag_limit_src=25.,
                                        survey=survey,
                                        verbose_object=verbose_object)

    data = np.concatenate((data_lens, data_nons))
    labels = np.concatenate((labels_lens, labels_nons))

    # shuffle concatenated data
    if shuffle:
        Nlens = len(data_lens)
        Nnons = len(data_nons)
        Ntot = Nlens + Nnons
        print "shuffle arrays"
        arr = np.arange(Ntot)
        np.random.shuffle(arr)

        data = data[arr]
        labels = labels[arr]

    return data, labels




# ================================================
# Metadata logging
# ================================================
# ------------------------------------------------------------------------------
def make_metadata_log(my_system):
    """Create Data Dictionary."""
    metadata_log = my_system.__dict__
    log.info("Make Meta data Log")
    try: 
        del metadata_log["model"]
    except:
        pass
    try:
        del metadata_log["history"]
    except:
        pass

    return metadata_log


# ------------------------------------------------------------------------------
def update_metadata_log(metadata_log, **kwargs):
    """Update Data Dictionary."""
    # loop over keyword arguments
    for k,v in kwargs.iteritems():
        metadata_log[k] = v

    return metadata_log


# ------------------------------------------------------------------------------
def save_metadata_log(dir_runlist, metadata_log, id_model=None, id_analysis=None):
    """Save Model Data Dictionary."""
    if id_model is not None:
        f_io =  "Model" + str(id_model).zfill(3) + "_Log" + ".json"
    if id_analysis is not None:
        f_io =  "Analysis" + str(id_analysis).zfill(3) + "_Log" + ".json"

    f_io_full = dir_runlist + f_io

    with open(f_io_full, 'w') as f:
        json.dump(metadata_log, f, sort_keys = True, indent = 4)


# ------------------------------------------------------------------------------
def load_metadata_log(dir_runlist, id_model=None, id_analysis=None):
    """Save Model Data Dictionary."""
    if id_model is not None:
        f_io =  "Model" + str(id_model).zfill(3) + "_Log" + ".json"
    if id_analysis is not None:
        f_io =  "Analysis" + str(id_analysis).zfill(3) + "_Log" + ".json"

    f_io_full = dir_runlist + f_io

    with open(f_io_full) as data_file:    
        metadata_log = json.load(data_file)

    return metadata_log


# ------------------------------------------------------------------------------
def collate_metadata_log(dir_runlist):
    """Collate Data Dictionary into single file."""
    file_io_list = [os.path.join(dir_runlist, f) for f in os.listdir(dir_runlist) if os.path.isfile(os.path.join(dir_runlist, f))]

    i_count = 0
    for f_io in file_io_list:
        with open(f_io) as data_file:    
            metadata = json.load(data_file)
        
        for k, v in metadata.iteritems():
            metadata[k] = [v]

        metadata = Table(metadata)
        if i_count == 0:
            metadata_master = metadata
        else:
            metadata_master = vstack([metadata_master, metadata], join_type='outer')
        
        i_count += 1

    """
    names = metadata_master.colnames
    edit_list = ["id_model", "id_data_train", "id_data_valid", "id_data_test"]
    for iname, name in zip(range(len(edit_list)), edit_list):
        try:
            names.remove(name)
            names.insert(iname, name)
        except:
            pass
    """

    file_io_master = "./Metadata_master_log.csv"
    ascii.write(metadata_master, file_io_master, 
                delimiter=",", 
    #            names=names,
                fill_values=[(ascii.masked, '---')])



# ------------------------------------------------------------------------------
# def make_log(id_data, id_model, id_analysis=None):
def setup_logging(default_path='logging.json', 
         default_level=logging.INFO,
         env_key='LOG_CFG'): 
        """Log all output data."""
        # file_log = make_log_name(id_data, id_model, id_analysis=id_analysis)

        # file_log = "./test_log.txt"
        try:  # python 2.7+
            from logging import nullhandler
        except importerror:
            class nullhandler(logging.handler):
                """class null handler."""
                
                def emit(record):
                    """emit."""
                    pass
        path = default_path
        value = os.getenv(env_key, none)
        if value:
            path = value
        if os.path.exists(path):
            with open(path, 'rt') as f:
                myconfig = json.load(f)
            logging.config.dictconfig(myconfig)
        else:
            logging.basicconfig(level=default_level)

        # logging.getLogger(__name__)
    # logging.getLogger(__name__).addHandler(NullHandler())

    """
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            config = json.load(f)
        logging.config.dictConfig(config)
    else:
        logging.basicConfig(level=default_level)

    # Set default logging handler to avoid "No handler found" warnings.
    import logging
    try:  # Python 2.7+
        from logging import NullHandler
    except ImportError:
        class NullHandler(logging.Handler):
            def emit(record):
                pass

    logging.getLogger(__name__).addHandler(NullHandler())
    """

    return 



# ==============================================================================
# Main setup
# ==============================================================================
if __name__ == '__main__':
    print "main"
else:
    setup_logging()
    log = logging.getLogger(__name__)