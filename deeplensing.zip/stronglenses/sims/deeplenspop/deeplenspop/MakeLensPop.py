import distances
import numpy as np
import os
import sys
from scipy import interpolate
import cPickle,numpy,math
import indexTricks as iT
import pylab as plt
from PopulationFunctions import *
import warnings
import time
warnings.filterwarnings("ignore")
# logging
import logging.config

class LensPopulation(LensPopulation_):
    def  __init__(self,zlmax=2,sigfloor=250,D=None,reset=True,
                  bands=['F814W_ACS','g_SDSS','r_SDSS','i_SDSS','z_SDSS','Y_UKIRT','VIS']
                  ): #sadface
        self.sigfloor=sigfloor
        self.zlmax=zlmax
        self.bands=bands

        self.beginRedshiftDependentRelation(D,reset)
        self.beginLensPopulation(D,reset)

    def phi(self,sigma,z):
    #you can change this, but remember to reset the splines if you do.
        sigma[sigma==0]+=1e-6
        phi_star=(8*10**-3)*self.D.h**3
        alpha=2.32
        beta=2.67
        sigst=161
        phi=phi_star * \
            ((sigma*1./sigst)**alpha)*\
            numpy.exp(-(sigma*1./sigst)**beta)*beta/\
            math.gamma(alpha*1./beta)/\
            (1.*sigma)

        #phi*=(1+z)**(-2.5)
        self.nozdependence=True

        return phi


class SourcePopulation(SourcePopulation_):
    def  __init__(self,D=None,reset=False,
                  bands=['F814W_ACS','g_SDSS','r_SDSS','i_SDSS','z_SDSS','Y_UKIRT'],population="cosmos"
                  ):
        self.bands=bands
        self.beginRedshiftDependentRelation(D,reset)
        if population=="cosmos":
            self.loadcosmos()
        elif population=="lsst":
            self.loadlsst()


        #NB all the functions are in the inherited from class.

#,'VIS'

#========================================
class LensSample():
    """
    Wrapper for all the other objects so you can just call it, and then run
    Generate_Lens_Pop to get a fairly drawn lens population
    """
    def  __init__(self,D=None,reset=False,zlmax=2,sigfloor=100,
                  bands=['F814W_ACS','g_SDSS','r_SDSS','i_SDSS','z_SDSS','Y_UKIRT'],
                  cosmo=[0.3,0.7,0.7],sourcepop="lsst",
                  user="nord",
                  id_data=0,
                  mag_limit_lens=30., mag_limit_src=30.,
                  nb_sample=10000,
                  nb_verbose=10000,
                  myverbose=0
                  ):

        self.myverbose = myverbose

        self.nb_sample = nb_sample
        self.nb_verbose = nb_verbose

        # set directories
        dir_pop = prepare_directory(user, id_data)
        self.dir_data_lens = dir_pop + "class_1_lens/"
        self.dir_data_nons = dir_pop + "class_0_nons/"


        make_dir(self.dir_data_lens)
        make_dir(self.dir_data_nons)

        
        # set magnitude limits
        self.mag_limit_src = mag_limit_src
        self.mag_limit_lens = mag_limit_lens


        # Initialize population computations
        self.sourcepopulation=sourcepop
        if D==None:
            import distances
            D=distances.Distance(cosmo=cosmo)

        self.L=LensPopulation(reset=reset,sigfloor=sigfloor,zlmax=zlmax,bands=bands,D=D)

        self.S=SourcePopulation(reset=reset,bands=bands,D=D,population=sourcepop)

        self.E=EinsteinRadiusTools(D=D)


    
    def Lenses_on_sky(self):
        self.ndeflectors=self.L.Ndeflectors(self.L.zlmax)
        return self.ndeflectors

    def Generate_Lens_Pop(self,N,firstod=1,nsources=1,prunenonlenses=True,save=True):
        import time
        t0=time.clock()
        log.info("N objects:"+ str(N))
        if prunenonlenses==False: assert N<600000000
        log.info("-----------------------")
        log.info("Generating Populations.")
        log.info("-----------------------")

        self.lens={}
        self.reallens={}
        self.nonlens={}
        M=N*1
        l=-1
        l2=-1
        l3=-1
        while M>0:
            # timeleft="who knows"
            timeleft="time remain: "
            if M!=N:
                tnow=time.clock()
                ti=(tnow-t0)/float(N-M)
                timeleft=ti*M # /60.


            # print M,timeleft," minutes left"
            # print M,timeleft," seconds " # left"
            log.info(str(M) + " " + str(timeleft) + " seconds ") # left"
            if M>100000:
                n=100000
            else:
                n=M*1
            M-=n
            zl,sigl,ml,rl,ql=self.L.drawLensPopulation(n)
            zs,ms,xs,ys,qs,ps,rs,mstar,mhalo=self.S.drawSourcePopulation(n*nsources,sourceplaneoverdensity=firstod,returnmasses=True)

            zl1=zl*1
            sigl1=sigl*1
            for i in range(nsources-1):
                zl=numpy.concatenate((zl,zl1))
                sigl=numpy.concatenate((sigl,sigl1))

            b=self.E.sie_rein(sigl,zl,zs)
            for i in range(n):
                l +=1
                self.lens[l]={}
                if b[i]**2>(xs[i]**2+ys[i]**2):
                    self.lens[l]["lens?"]=True
                    # if self.myverbose == 1:
                    #    print "Lens"
                else:
                    self.lens[l]["lens?"]=False
                    # if self.myverbose == 1:
                    #    print "Not!"

                self.lens[l]["b"]={}
                self.lens[l]["zs"]={}
                self.lens[l]["zl"]=zl[i]
                self.lens[l]["sigl"]=sigl[i]
                for j in range(nsources):
                    self.lens[l]["zs"][j+1]=zs[i+j*n]
                    self.lens[l]["b"][j+1] =b[i+j*n]

                self.lens[l]["ml"]={}
                self.lens[l]["rl"]={}
                self.lens[l]["ms"]={}

                for band in ml.keys():
                        self.lens[l]["ml"][band]=ml[band][i]
                        self.lens[l]["rl"][band]=rl[band][i]
                self.lens[l]["ql"]=ql[i]

                self.lens[l]["ms"]={}
                self.lens[l]["xs"]={}
                self.lens[l]["ys"]={}
                self.lens[l]["rs"]={}
                self.lens[l]["qs"]={}
                self.lens[l]["ps"]={}
                self.lens[l]["mstar"]={}
                self.lens[l]["mhalo"]={}

                for j in range(nsources):
                    self.lens[l]["ms"][j+1]={}
                    for band in ml.keys():
                        self.lens[l]["ms"][j+1][band]=ms[band][i+j*n]
                    self.lens[l]["zs"][j+1]=zs[i+j*n]
                    self.lens[l]["b"][j+1] =b[i+j*n]
                    self.lens[l]["xs"][j+1]=xs[i+j*n]
                    self.lens[l]["ys"][j+1]=ys[i+j*n]
                    self.lens[l]["rs"][j+1]=rs[i+j*n]
                    self.lens[l]["qs"][j+1]=qs[i+j*n]
                    self.lens[l]["ps"][j+1]=ps[i+j*n]
                    self.lens[l]["mhalo"][j+1]=mstar[i+j*n]
                    self.lens[l]["mstar"][j+1]=mhalo[i+j*n]

                # cut on the magnitudes
                band_list=['g_SDSS', 'r_SDSS', "i_SDSS"]
                pass_dict={0: False, 1: False, 2: False, 3: True}

                photom_lens = self.lens[l]["ml"]
                mag_list = np.array([mag
                                    for label, mag in photom_lens.iteritems()
                                    if label in band_list])
                check_limit = len(np.where(mag_list < self.mag_limit_lens)[0])
                pass_photom_lens =  (check_limit >= 1) # pass_dict[check_limit]

                photom_src = self.lens[l]['ms'][1]
                mag_list = np.array([mag
                                    for label, mag in photom_src.iteritems()
                                    if label in band_list])
                check_limit = len(np.where(mag_list < self.mag_limit_src)[0])
                pass_photom_src = (check_limit >= 1) # pass_dict[check_limit]

                pass_photom = pass_photom_src & pass_photom_lens

                if not pass_photom:
                    continue

                # nb_sample = 10000
                if self.lens[l]["lens?"]:
                    l2+=1
                    self.reallens[l2]=self.lens[l].copy()
                    if (l2+1)%self.nb_verbose == 0:
                        log.info("lens: " + str(i) + " " + str(l2))

                    if (l2+1)%self.nb_sample==0:
                        fn=self.dir_data_lens +"lenspars_pop_lens_%s_%i.pkl"%(self.sourcepopulation,i)
                        f=open(fn,'wb')
                        cPickle.dump(self.reallens,f,2)
                        f.close()
                        if self.myverbose:
                            # print "!!! ", fn
                            log.info("----")
                            log.info("LENS: " + fn)
                            log.info("----")
                        del self.reallens
                        self.reallens={}
                        del self.lens
                        self.lens = {}

                elif not self.lens[l]["lens?"]:
                    l3+=1
                    self.nonlens[l3] = self.lens[l].copy()
                    if (l3+1)%self.nb_verbose == 0:
                        log.info("nons: " + str(i) + " " + str(l3))

                    if (l3+1)%self.nb_sample==0:
                        fn=self.dir_data_nons +"lenspars_pop_nons_%s_%i.pkl"%(self.sourcepopulation,i)
                        f=open(fn,'wb')
                        cPickle.dump(self.nonlens,f,2)
                        f.close()
                        if self.myverbose:
                            log.info("NONS: " + fn)
                        del self.nonlens
                        self.nonlens={}
                        del self.lens
                        self.lens = {}

        if len(self.reallens) > 0:
            fn=self.dir_data_lens + "lenspars_pop_lens.pkl"
            f=open(fn,'wb')
            cPickle.dump(self.reallens,f,2)
            f.close()
            if self.myverbose:
                log.info("----")
                log.info("LENS: " + fn)
                log.info("----")
        if len(self.nonlens) > 0:
            fn=self.dir_data_nons + "lenspars_pop_nons.pkl"
            f=open(fn,'wb')
            cPickle.dump(self.nonlens,f,2)
            f.close()
            if self.myverbose:
                log.info("NONS: " + fn)
        log.info("-----------------------------------")
        log.info("FINISHED Making Lens Population")
        log.info("Lens Count: " + str(l2))
        log.info("Nons Count: " + str(l3))
        log.info(" ")

        """
        if save:
            print "test", l2
            # fn="idealisedlenses/lens/lenspopulation_%s_%i.pkl"%(self.sourcepopulation,l2)
            fn=self.dir_data_lens + "lenspopulation_%s_%i.pkl"%(self.sourcepopulation,l2)
            #fn="idealisedlenses/lenspopulation_%s_residual_%i.pkl"%(self.sourcepopulation,l2)
            print "file_output:", fn
            f=open(fn,'wb')
            protocol = 2
            cPickle.dump(self.reallens,f,protocol)
            f.close()

        if prunenonlenses==False:

          if save:
            t0 = time.time()
            # myfile = "idealisedlenses/nonlenspopulation_%s.pkl"%self.sourcepopulation
            protocol = 2
            nb_sample = 1000
            Nlens = len(self.lens)
            if nb_sample > Nlens:
                nb_sample = Nlens
            l3 = -1
            self.nonlens = {}
            for ind in range(len(self.lens)):
                l3 += 1
                self.nonlens[l3] = self.lens[ind].copy()
                if (l3+1)%nb_sample==0:
                    #myfile = "idealisedlenses/nons/nonlenspopulation_%s_%i.pkl"%(self.sourcepopulation,ind)
                    myfile = self.dir_data_nons + "nonlenspopulation_%s_%i.pkl"%(self.sourcepopulation,l3)
                    f=open(myfile,'wb')
                    cPickle.dump(self.nonlens,f,protocol)
                    f.close()
                    print "output lens dictionary", len(self.nonlens), myfile
                    del self.nonlens
                    self.nonlens = {}
            t1 = time.time()
            print "output lens dictionary", len(self.nonlens), myfile, t1-t0
            # print len(self.lens.keys())

        self.lens=self.reallens
        """


    def LoadLensPop(self,j=0,sourcepopulation="lsst"):
        #f=open("idealisedlenses/lens/lenspopulation_%s_%i.pkl"%(sourcepopulation,j),'rb')
        f=open(self.dir_data_lens + "lenspopulation_%s_%i.pkl"%(sourcepopulation,j),'rb')
        self.lens=cPickle.load(f)
        f.close()


    def Pick_a_lens(self,i=None,dspl=False,tspl=False):
        if i ==None:
            numpy.random.randint(0,self.n)

        self.rli={}
        self.mli={}
        self.msi={}
        self.msi2={}
        self.msi3={}

        for band in self.L.bands:
            self.rli[band]=self.rl[band][i]
            self.mli[band]=self.ml[band][i]
        for band in self.S.bands:
            self.msi[band]=self.ms[band][i]
            if dspl or tspl:
                self.msi2[band]=self.ms2[band][i]
                if tspl:self.msi3[band]=self.ms3[band][i]

        preselection=self.apply_preselection(self.mli["i_SDSS"],self.zl[i])
        if dspl==False and tspl==False:
            return [self.mli,self.rli,self.ql[i],self.bl[i]],[self.msi,self.xs[i],self.yl[i],self.qs[i],self.ps[i],self.rs[i]],[self.zl[i],self.zs[i]],preselection
        elif tspl==False:
            return [self.mli,self.rli,self.ql[i],self.bl[i]],[self.msi,self.xs[i],self.yl[i],self.qs[i],self.ps[i],self.rs[i]],[self.bl2[i],self.msi2,self.xs2[i],self.yl2[i],self.qs2[i],self.ps2[i],self.rs2[i]],[self.zl[i],self.zs[i],self.zs2[i],self.sigl[i],self.Mvs[i],self.r_phys[i]],preselection

        else:
            return [self.mli,self.rli,self.ql[i],self.bl[i]],    [self.msi,self.xs[i],self.yl[i],self.qs[i],self.ps[i],self.rs[i]],     [self.bl2[i],self.msi2,self.xs2[i],self.yl2[i],self.qs2[i],self.ps2[i],self.rs2[i]],     [self.bl3[i],self.msi3,self.xs3[i],self.yl3[i],self.qs3[i],self.ps3[i],self.rs3[i]],     [self.zl[i],self.zs[i],self.zs2[i],self.zs3[i],self.sigl[i],self.Mvs[i],self.r_phys[i]],     preselection


    def apply_preselection(self,imag,z):
        if imag<15: return False
        if imag>23:return False
        if z<0.05: return False
        return True


def run_population(user, id_data,
                   fsky, zlmax,
                   zmin=0,
                   sigfloor=100, 
                   nsources=1,
                   nb_verbose=1000,
                   nb_sample=10000,
                   myverbose=0):

    log.info("-----------------------")
    log.info("Run Population Estimation.")
    log.info("-----------------------")
    
    D=distances.Distance()
    
    Lpop=LensPopulation(reset=True,sigfloor=sigfloor,zlmax=zlmax,D=D)
    
    Ndeflectors=Lpop.Ndeflectors(1,zmin=zmin,fsky=fsky)
    
    L=LensSample(reset=False, 
                 cosmo=[0.3,0.7,0.7], 
                 sourcepop="lsst", 
                 sigfloor=sigfloor, 
                 user=user,
                 id_data=id_data,
                 mag_limit_lens=30.,
                 mag_limit_src=30.,
                 nb_sample=nb_sample,
                 nb_verbose=nb_verbose,
                 myverbose=myverbose)
    
    L.Generate_Lens_Pop(int(Ndeflectors),firstod=1,nsources=nsources,prunenonlenses=False)


def make_dir(dir):
    """Make Directories."""
    try:
        os.makedirs(dir)
    except OSError:
        if not os.path.isdir(dir):
            raise
    return 0



def prepare_directory(user, id_data):

    # ------------------------
    # set base data directory
    # ------------------------
    uname = os.uname()
    system_name = uname[1]
    if "des" in system_name:
        dir_system = "/data/des40.b/data/nord/"
    else:
        dir_system = "/Users/" + user + "/Dropbox/"

    # base directory
    dir_deeplensing = dir_system + "deeplensing/"
    dir_data = dir_deeplensing + "Data/Simulation/SimLensPop/"
    dir_run = dir_data + "Data" + str(id_data).zfill(3) + "/"
    dir_pop = dir_run + "Population/"

    return dir_pop


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# def make_log(id_data, id_model, id_analysis=None):
def setup_logging(default_path='logging.json', 
                  default_level=logging.INFO,
                  env_key='LOG_CFG'): 
    """Log all output data."""
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            myconfig = json.load(f)
        logging.config.dictconfig(myconfig)
    else:
        logging.basicConfig(level=default_level)

    return 

if __name__ == "__main__":
    """
    myverbose = 0
    fsky=0.1
    run = 8
    D=distances.Distance()
    Lpop=LensPopulation(reset=True,sigfloor=100,zlmax=1,D=D)
    Ndeflectors=Lpop.Ndeflectors(1,zmin=0,fsky=fsky)
    L=LensSample(reset=False,sigfloor=100,cosmo=[0.3,0.7,0.7],sourcepop="lsst",run_number=run)
    L.Generate_Lens_Pop(int(Ndeflectors),firstod=1,nsources=1,prunenonlenses=False)
    """

    user = "nord"
    id_data = 70
    fsky = 0.001
    zlmax = 1.1

    run_population(user, id_data,
                   fsky, zlmax,
                   zmin=0,
                   sigfloor=100, 
                   nsources=1,
                   myverbose=0)

else:
    setup_logging()
    log = logging.getLogger(__name__)
    