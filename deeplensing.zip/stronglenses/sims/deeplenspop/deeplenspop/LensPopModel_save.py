import os
import sys
# from astropy.io import fits
from FastLensSim import *
from ColorizeFunction import Colorize
import numpy as np


def GenerateLensParameters(zl, zs, be, xs, ys, Lenstype=True, **kwargs):
    """Set lens pars"""
    lenspars = {
        'zl': 1.0,
        'zs': {1: 1.5},
        'ps': {1: 90.0},
        'qs': {1: 0.19031817426687943},
        'b': {1: 5.},
        'lens?': True,
        'rs': {1: 0.11273429289548288},
        'ml': {
            'g_SDSS': 25.764342164961832,
            'r_SDSS': 22.918909056282573,
            'i_SDSS': 21.669371051501813,
            'z_SDSS': 20.353736610804404,
            'F814W_ACS': 21.008432268442618,
            'Y_UKIRT': 19.78383167424828
        },
        'sigl': 391.03020182762191,
        'mhalo': {1: 0.46039999999999998},
        'ms': {1: {
            'g_SDSS': 23.38,
            'r_SDSS': 23.60,
            'i_SDSS': 23.58,
            'z_SDSS': 23.55,
            'F814W_ACS': 21.58,
            'Y_UKIRT': 2128.5093999999999
        }},
        'rl': {
            'g_SDSS': 0.47511297207625075,
            'r_SDSS': 0.47511297207625075,
            'i_SDSS': 0.47511297207625075,
            'z_SDSS': 0.47511297207625075,
            'F814W_ACS': 0.47511297207625075,
            'Y_UKIRT': 0.47511297207625075
        },
        'xs': {1: .3146192669123881},
        'ys': {1: .3029063512358129409},
        'mstar': {1: 20.397600000000001},
        'ql': 0.61276676378304762
    }

    lenspars = {
        'b': {1: 0.54556853558189777},
        'lens?': True,
        'mhalo': {1: 0.10539999999999999},
        'ml': {'F814W_ACS': 21.983378610049847,
               'Y_UKIRT': 21.090647325921669,
               'g_SDSS': 26.151242946930644,
               'i_SDSS': 22.395153074240355,
               'r_SDSS': 23.8571041448789,
               'z_SDSS': 21.561114891443776},
        'ms': {1: {'F814W_ACS': 26.995200000000001,
                   'Y_UKIRT': 2675.4155999999998,
                   'g_SDSS': 27.543299999999999,
                   'i_SDSS': 26.995200000000001,
                   'r_SDSS': 27.026499999999999,
                   'z_SDSS': 27.0244}},
        'mstar': {1: 9.6394000000000002},
        'ps': {1: 143.50649280415229},
        'ql': 0.83017202880494501,
        'qs': {1: 0.29399054698465366},
        'rl': {'F814W_ACS': 0.43112935432779748,
               'Y_UKIRT': 0.43112935432779748,
               'g_SDSS': 0.43112935432779748,
               'i_SDSS': 0.43112935432779748,
               'r_SDSS': 0.43112935432779748,
               'z_SDSS': 0.43112935432779748},
        'rs': {1: 0.058848950387115274},
        'sigl': 175.30122314360003,
        'xs': {1: 0.1414747081111444},
        'ys': {1: 0.43135313860155838},
        'zl': 0.76108273925537995,
        'zs': {1: 3.7244999999999999}
    }

    """
    lenspars['zl'] = zl
    lenspars['zs'][1] = zs
    lenspars['b'][1] = be
    lenspars['xs'][1] = xs
    lenspars['ys'][1] = ys
    lenspars['lens?'] = Lenstype

    if Lenstype is False:
        for key, value in lenspars['ms'][1].iteritems():
            lenspars['ms'][1][key] = 99.
    """

    return lenspars


def GenerateLensSample(lenspars, i,
                       survey="Custom",
                       nsources=1,
                       SNcutA=100,
                       magcut=10,
                       SNcutBmin=1000,
                       SNcutBmax=1000,
                       Lenstype=True):
    """Generate lens sample based on survey parameters"""
    # Create Survey Simulation set
    SimSet = FastLensSim(survey)
    SimSet.bfac = float(2)
    SimSet.rfac = float(2)

    # visi5le magnitude value
    lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                             lenspars["rl"]["i_SDSS"] +
                             lenspars["rl"]["z_SDSS"]) / 3
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["SN"] = {}
    lenspars["bestband"] = {}
    lenspars["pf"] = {}
    lenspars["resolved"] = {}
    lenspars["poptag"] = {}
    lenspars["seeing"] = {}
    lenspars["rfpf"] = {}
    lenspars["rfsn"] = {}

    # mi in ml
    for mi in [lenspars["ml"], lenspars["ms"][1]]:
        mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

    # SimSet.xl = 20.
    # SimSet.yl = 20.
    # SimSet.r2 = (SimSet.x-SimSet.xl)**2+(SimSet.y-SimSet.yl)**2

    # print "\t ... set lens pars"
    SimSet.setLensPars(lenspars["ml"],
                       lenspars["rl"],
                       lenspars["ql"],
                       reset=True)

    # set source parameters
    for j in range(nsources):
        jj = j + 1
        SimSet.setSourcePars(lenspars["b"][jj],
                             lenspars["ms"][jj],
                             lenspars["xs"][jj],
                             lenspars["ys"][jj],
                             lenspars["qs"][jj],
                             lenspars["ps"][jj],
                             lenspars["rs"][jj],
                             sourcenumber=jj)

    # print "\t ... not last survey"
    model = SimSet.makeLens(stochasticmode="MP")
    SOdraw = numpy.array(SimSet.SOdraw)

    # print "simset images a", len(SimSet.image)

    # for key, value in SimSet.seeing.iteritems():
    #    SimSet.seeing[key] = 5.0

    # print "\t ... get meta data"
    # SimSet.SourceMetaData(SNcutA=a, magcut=b, SNcutB=[c, d])
    mag, msrc, SN, bestband, pf = \
        SimSet.SourceMetaData(SNcutA=SNcutA, magcut=magcut,
                              SNcutB=[SNcutBmin, SNcutBmax])

    # print "simset images b", len(SimSet.image)

    lenspars["SN"][survey] = {}
    lenspars["bestband"][survey] = {}
    lenspars["pf"][survey] = {}
    lenspars["resolved"][survey] = {}
    lenspars["poptag"][survey] = i
    lenspars["seeing"][survey] = SimSet.seeing

    rfpf = {}
    rfsn = {}

    # print "\t ... Sources: ", SimSet.sourcenumbers
    for src in SimSet.sourcenumbers:
        rfpf[src] = False
        rfsn[src] = [0]
        lenspars["mag"][src] = mag[src]
        lenspars["msrc"][src] = msrc[src]
        lenspars["SN"][survey][src] = SN[src]
        lenspars["bestband"][survey][src] = bestband[src]
        lenspars["pf"][survey][src] = pf[src]
        lenspars["resolved"][survey][src] = SimSet.resolved[src]

    # print "\t ... ... make lens"
    # print "\t set lens pars"
    SimSet.makeLens(noisy=True,
                    stochasticmode="1P",
                    SOdraw=SOdraw,
                    MakeModel=False)

    # print "simset images c", len(SimSet.image)

    # sys.exit()
    lenspars["rfpf"][survey] = rfpf
    lenspars["rfsn"][survey] = rfsn

    return SimSet


def SaveImages(SimSet,
               survey="Custom",
               folder="ImagesNew/",
               outfile="test.png"):
    """Save Images"""

    # make directory
    if not os.path.isdir(folder):
        os.mkdir(folder)

    # print "\t ... my folder", folder
    myimage = Colorize(dir_output=folder, outfile=outfile)
    Nchannel = 3
    Nside = SimSet.side
    imgsave = np.ndarray((Nchannel, Nside, Nside))
    print "bands:", SimSet.bands
    print "simset image", SimSet.image
    for ichan, band, band_color in zip(range(Nchannel),
                                       SimSet.bands,
                                       ["G", "R", "I"]):
        img = SimSet.image[band]
        myimage.read_data_object(band_color, img)
        imgsave[ichan] = img
    myimage.ProcessFile()

    return imgsave


def GenerateLens(params, dir_output, Lenstype=True, **kwargs):
    data = []
    # metadata_lenspars = {}
    metadata_lenspars = []
    Ndata = len(params)
    outfile_base = "color_image"
    for i, param in zip(range(Ndata), params):

        [zl, zs, be, xs, ys] = param
        lenspars = GenerateLensParameters(zl, zs, be, xs, ys,
                                          Lenstype=Lenstype)
        SimSet_temp = GenerateLensSample(lenspars, i,
                                         survey="Custom",
                                         nsources=1,
                                         SNcutA=10,
                                         magcut=10,
                                         SNcutBmin=2000,
                                         SNcutBmax=2000,
                                         Lenstype=Lenstype
                                         )
        print SimSet_temp.image
        outfile = outfile_base + str(i).zfill(4) + ".png"
        img = SaveImages(SimSet_temp,
                         survey="LSSTa",
                         folder=dir_output,
                         outfile=outfile)

        data.append(img)
        # metadata_lenspars[str(i)] = lenspars
        metadata_lenspars.append(lenspars)

        print "object: " + str(i + 1).zfill(4) + " / " + str(Ndata).zfill(4)

    data = np.array(data)
    metadata_lenspars = np.array(metadata_lenspars)

    if Lenstype:
        labels = np.ones((Ndata), dtype=int)
    else:
        labels = np.zeros((Ndata), dtype=int)

    return data, labels, metadata_lenspars


def SaveDataArrays(data, labels, metadata, dir_output):
    """Save Data arrays"""
    np.save(dir_output + 'xtrain.npy', data)
    np.save(dir_output + 'ytrain.npy', labels)
    np.save(dir_output + 'metadata_lens.npy', metadata)


def demo():
    """Demo/run script"""
    dir_output_base = "./ImagesNew/"
    dir_output_len = dir_output_base + "Lens/"
    dir_output_non = dir_output_base + "Non/"

    # make directory
    if not os.path.isdir(dir_output_len):
        os.mkdir(dir_output_len)
    if not os.path.isdir(dir_output_non):
        os.mkdir(dir_output_non)

    # xsmin,dxs = 1., 1.
    zlrange = np.arange(1.0, 2.0, 1.0)
    zsrange = np.arange(2.0, 4.0, 1.0)
    berange = np.arange(0.0, 1.0, 1.0)
    xsrange = np.arange(0.1, 0.2, 0.1)
    ysrange = np.arange(0.1, 0.2, 0.1)

    params = [[zl, zs, be, xs, ys]
              for zl in zlrange
              for zs in zsrange
              for be in berange
              for xs in xsrange
              for ys in ysrange]

    metadata_lenspop = {
        "zlrange": zlrange,
        "zsrange": zsrange,
        "berange": berange,
        "xsrange": xsrange,
        "ysrange": ysrange
    }

    np.save(dir_output_base + 'metadata_lenspop.npy', metadata_lenspop)

    dataset_len = GenerateLens(params, dir_output_len, Lenstype=True)
    #dataset_non = GenerateLens(params, dir_output_non, Lenstype=False)

    '''
    data_len, labels_len, metadata_len = dataset_len
    data_non, labels_non, metadata_non = dataset_non

    # join tables
    data_tot = np.concatenate((data_len, data_non))
    labels_tot = np.concatenate((labels_len, labels_non))
    metadata_tot = np.concatenate((metadata_len, metadata_non))

    # save tables
    SaveDataArrays(data_tot, labels_tot, metadata_tot, dir_output_base)
    '''

# set noise level, psf amount. What other common features might you expect
# how to add discrete types of noise to images: foregroudn objects, edge effects, stars, etc.
# goals: find new lenses in some data sets

# find out what the rest of the parameters are
# how much code do we need to run this? can we get rid of a bunch of files
# define some questions; get some plots for paper
# in the LensPop directory?


demo()
