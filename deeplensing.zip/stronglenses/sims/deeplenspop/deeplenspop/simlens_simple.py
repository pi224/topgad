import sys

import simlens as sl
import MakeLensPop as mlp

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Generate a Single Sample
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
def grid(sample_parameters):
    """Generate single example."""
    # set run parameters

    #var sigl 99.255003022 385.085393371
    ######var ps 0.0140857359445 179.987982201
    #var rs 0.000787606265032 31.7571827207
    #var xs -2.04122555107 2.04120190187
    #var ys -2.04069221618 2.04112853548
    #var zs 0.0421 6.7928
    #var qs 0.200347772253 0.999428819355
    #var ql 0.200066182665 0.99824979097
    #var ml_g_sdss 13.6521741324 32.1802322409
    #var ml_r_sdss 12.669780515 31.7672344241
    #var ml_i_sdss 12.3071823426 29.9998438677
    #var ml_z_sdss 12.0106594789 28.1140169664
    #var rl_g_sdss 0.0738987717658 7.07582824835
    #var rl_r_sdss 0.0738987717658 7.07582824835
    #var rl_i_sdss 0.0738987717658 7.07582824835
    #var rl_z_sdss 0.0738987717658 7.07582824835
    #var ms_g_sdss 17.1739 35.8209
    #var ms_r_sdss 16.3804 32.7593
    #var ms_i_sdss 16.0039 29.989
    #var ms_z_sdss 15.7655 29.862
    #var mag 4.45354879737e-50 240.789529028
    #var mstar 0.5164 25150.9707

    # set sample parameters
    '''
    sample_parameters = {
                        "data_set_type": "grid",
                        "id_data": 93,
                        "survey": "Custom",
                        "psf_fac": 1.0,
                        "exp_fac": 1.0,
                        "nb_side_pix": 64,
                        "seed": 827282,
                        "nb_classes": 2,
                        "nb_channels": 3,
                        "be_min": 0.1,
                        "be_max": 3.1,
                        "xs_min": -2.0,
                        "xs_max": 2.0,
                        "ys_min": -2.0,
                        "ys_max": 2.0,
                        "zs_min": 0.05,
                        "zs_max": 6.8,
                        "zl_min": 0.025,
                        "zl_max": 2.00,
                        "ml_g_min": 12.00,
                        "ml_r_min": 12.00,
                        "ml_i_min": 12.00,
                        "ml_z_min": 12.00,
                        "ml_g_max": 32.50,
                        "ml_r_max": 32.50,
                        "ml_i_max": 32.50,
                        "ml_z_max": 32.50,
                        "ms_g_min": 15.50,
                        "ms_r_min": 15.50,
                        "ms_i_min": 15.50,
                        "ms_z_min": 15.00,
                        "ms_g_max": 36.00,
                        "ms_r_max": 36.00,
                        "ms_i_max": 36.00,
                        "ms_z_max": 36.00,
                        "jiggle": 0.0,
                        "classes": {
                                    0:
                                        {
                                            "name": "nons",
                                            "nb_sample":10,
                                            "class": False
                                        },
                                    1:
                                        {
                                            "name": "lens",
                                            "nb_sample":10,
                                            "class": True
                                        }

                                    }
                        }
    '''

    user = sample_parameters["user"] #"nord"
    overwrite =sample_parameters["overwrite"]# True

    # prepare directories
    dirs = sl.prepare_directory(user, sample_parameters)

    # lens class 1: lenses
    lenspars_set_1 = sl.generate_lenspars_set(sample_parameters, id_class="1")
    data_1, labels_1, ids_1, lenspars_set_1  =\
        sl.generate_lens_sample(dirs["data"], lenspars_set_1, sample_parameters, id_class="1")

    # lens class 0: non-lenses
    ids_start_new = ids_1[-1] + 1
    lenspars_set_0 = sl.generate_lenspars_set(sample_parameters, id_class="0")
    data_0, labels_0, ids_0, lenspars_set_0  =\
        sl.generate_lens_sample(dirs["data"], lenspars_set_0, sample_parameters, id_class="0", ids_start=ids_start_new)

    # combine data sets
    data_list = [data_1, data_0]
    labels_list = [labels_1, labels_0]
    ids_list = [ids_1, ids_0]
    lenspars_set_list = [lenspars_set_1, lenspars_set_0]
    data, labels, ids, lenspars = sl.combine_data(data_list, labels_list, ids_list, lenspars_set_list)

    # shuffle data set
    ndata = len(data)
    inds_shuffle, inds_deshuffle = sl.make_shuffle_indices(ndata)
    data, labels, ids, lenspars = sl.shuffle_data(inds_shuffle, data, labels, ids, lenspars)

    # save data
    sl.save_data(dirs, sample_parameters,
                 data, labels, ids, lenspars,
                 inds_deshuffle=inds_deshuffle,
                 overwrite=overwrite)



# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Generate a single Population
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
def population(sample_parameters):
    """Generate population sample."""

    user = sample_parameters["user"] #"nord"
    overwrite =sample_parameters["overwrite"]# True

    # prepare directories
    dirs = sl.prepare_directory(user, sample_parameters)

    # run population creator
    mlp.run_population(user,
                       sample_parameters["id_data"],
                       sample_parameters["fsky"],
                       sample_parameters["zlmax"],
                       nsources=sample_parameters["nsources"],
                       zmin=sample_parameters["zmin"],
                       sigfloor=100,
                       nb_sample=100000,
                       nb_verbose=10000000,
                       myverbose=True)



    # generate lens sample
    lenspars_set_1 = sl.load_lenspars_pop(dirs['population'], id_class=1)
    sample_parameters["classes"][1]["nb_sample"] = len(lenspars_set_1)
    data_1, labels_1, ids_1, lenspars_set_1 =\
        sl.generate_lens_sample(dirs["data"], lenspars_set_1, sample_parameters, id_class=1)

    # generate lens sample
    lenspars_set_0 = sl.load_lenspars_pop(dirs["population"], id_class=0)
    sample_parameters["classes"][0]["nb_sample"] = len(lenspars_set_0)
    data_0, labels_0, ids_0, lenspars_set_0 =\
        sl.generate_lens_sample(dirs["data"], lenspars_set_0, sample_parameters, id_class=0)

    # combine data sets
    data_list = [data_1, data_0]
    labels_list = [labels_1, labels_0]
    ids_list = [ids_1, ids_0]
    lenspars_set_list = [lenspars_set_1, lenspars_set_0]
    data, labels, ids, lenspars = sl.combine_data(data_list, labels_list, ids_list, lenspars_set_list)

    # shuffle data set
    ndata = len(data)
    inds_shuffle, inds_deshuffle = sl.make_shuffle_indices(ndata)
    data, labels, ids, lenspars = sl.shuffle_data(inds_shuffle, data, labels, ids, lenspars)

    # save data
    sl.save_data(dirs, sample_parameters,
                 data, labels, ids, lenspars,
                 inds_deshuffle=inds_deshuffle,
                 overwrite=overwrite)



# ==============================================================================
# Main setup
# ==============================================================================
if __name__ == '__main__':
    import argparse
    description = __doc__
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('simtype',
                        help="The type of simulation: grid or population")
    parser.add_argument('infile',metavar='run.json',
                        help="Input json file with parameters")

    opts = parser.parse_args()


    file_input = opts.infile

    import distutils.util
    def make_bool(bool_string):
        """Switch bool string to bool."""
        #return bool(bool_string)
        return bool(distutils.util.strtobool(bool_string))

    #def make_string(number):
    #    """Make a key in a dictionary a string instead."""


    import json
    with open(file_input) as data_file:    
        params = json.load(data_file)

    for key, val in params.items():
        if val in ["True", "False"]: 
            params[key] = make_bool(val)

    if opts.simtype == "grid":
        grid(params)
    elif opts.simtype == "population":
        population(params)


