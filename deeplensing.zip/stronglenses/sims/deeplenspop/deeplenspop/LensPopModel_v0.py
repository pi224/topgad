from __init__ import *
import cPickle
import sys
import os
import time

from ColorizeFunction import Colorize
from FastLensSim import *


L = LensSample(reset=False, sigfloor=sigfloor, cosmo=[0.3, 0.7, 0.7])


def SaveImages(i, S, L):
    folder = "SimImages/%i" % (i)
    if not os.path.isdir(folder):
        os.mkdir(folder)
    print "\t ... my folder", folder
    for band in S[survey].bands:
        print "test", band
        img = S[survey].image[band]
        sig = S[survey].sigma[band]
        psf = S[survey].psf[band]
        resid = S[survey].fakeResidual[0][band]     # The lens subtracted

        pyfits.PrimaryHDU(img).writeto("%s/image_%s.fits" % (folder, band),
                                       clobber=True)
        pyfits.PrimaryHDU(sig).writeto("%s/sigma_%s.fits" % (folder, band),
                                       clobber=True)
        pyfits.PrimaryHDU(psf).writeto("%s/psf_%s.fits" % (folder, band),
                                       clobber=True)
        pyfits.PrimaryHDU(resid).writeto("%s/galsub_%s.fits" % (folder, band),
                                         clobber=True)

    ###
    dir_input = folder + "/"  # "/Users/nord/Projects/LensPop/SimImages/1/"
    filenameG = "image_g_SDSS.fits"
    filenameR = "image_r_SDSS.fits"
    filenameI = "image_i_SDSS.fits"
    myimage = Colorize(dir_input, filenameG, filenameR, filenameI)
    myimage.ProcessFile()

    L.lens[i] = None  # delete used data for memory saving


class LensPop(object):

    def __init__(self):
        self.sigfloor = 300
        self.experiment = "LSST"
        self.frac = 0.001
        self.nsources = 1

        a = 150     # SN threshold
        b = 10      # Magnification threshold
        c = 2000
        d = 2000

        self.surveys = ['test']

        S = {}
        n = {}
        for survey in surveys:
            print 'test survey', survey
            S[survey] = FastLensSim(survey, fractionofseeing=1)
            S[survey].bfac = float(2)
            S[survey].rfac = float(2)

        for sourcepop in ["lsst"]:
            chunk = 0
            Si = 0
            SSPL = {}

            nall = 100


  L.LoadLensPop(0,sourcepop)
  print "about to load"
  print 0,nall
  nall = len(L.lens)
  nall = 10
  print "loop over lenses", nall
  for i in range(1, nall):

lenspars = {
               'zl': 0.5,
                'zs': {1: 2.5},
                'ps': {1: 38.250903302932855},
                'qs': {1: 0.19031817426687943},
                'b': {1: 2.5},
                'lens?': True,
                'rs': {1: 0.31273429289548288},
                'ml': {
                        'g_SDSS': 25.764342164961832,
                        'r_SDSS': 22.918909056282573,
                        'i_SDSS': 21.669371051501813,
                        'z_SDSS': 20.353736610804404,
                        'F814W_ACS': 21.008432268442618,
                        'Y_UKIRT': 19.78383167424828
                        },
                'sigl': 291.03020182762191,
                'mhalo': {1: 0.46039999999999998},
                'ms': {1: {
                        'g_SDSS': 21.38,
                        'r_SDSS': 21.60,
                        'i_SDSS': 21.58,
                        'z_SDSS': 21.55,
                        'F814W_ACS': 21.58,
                        'Y_UKIRT': 2128.5093999999999
                        }},
                'rl': {
                        'r_SDSS': 0.47511297207625075,
                        'z_SDSS': 0.47511297207625075,
                        'F814W_ACS': 0.47511297207625075,
                        'Y_UKIRT': 0.47511297207625075,
                        'g_SDSS': 0.47511297207625075,
                        'i_SDSS': 0.47511297207625075},
                'xs': {1: 0.3146192669123881},
                'ys': {1: 0.3029063512358129409},
                'mstar': {1: 20.397600000000001},
                'ql': 0.61276676378304762
                }

    lenspars["rl"]["VIS"]=(lenspars["rl"]["r_SDSS"]+\
                           lenspars["rl"]["i_SDSS"]+lenspars["rl"]["z_SDSS"])/3
    for mi in [lenspars["ml"],lenspars["ms"][1]]:
        mi["VIS"]=(mi["r_SDSS"]+mi["i_SDSS"]+mi["z_SDSS"])/3


    lenspars["mag"]={}
    lenspars["msrc"]={}
    lenspars["mag"]={}
    lenspars["msrc"]={}
    lenspars["SN"]={}
    lenspars["bestband"]={}
    lenspars["pf"]={}
    lenspars["resolved"]={}
    lenspars["poptag"]={}
    lenspars["seeing"]={}
    lenspars["rfpf"]={}
    lenspars["rfsn"]={}

    lastsurvey="non"
    print "\t loop over surveys", surveys
    for survey in surveys:

        print "\t ... set lens pars"
        S[survey].setLensPars(lenspars["ml"],lenspars["rl"],lenspars["ql"],reset=True)
        for j in range(nsources):
            S[survey].setSourcePars(lenspars["b"][j+1],lenspars["ms"][j+1],\
                                    lenspars["xs"][j+1],lenspars["ys"][j+1],\
                                    lenspars["qs"][j+1],lenspars["ps"][j+1],\
                                    lenspars["rs"][j+1],sourcenumber=j+1    )

        if survey[:3]+str(i)!=lastsurvey:
            print "\t ... not last survey"
            model=S[survey].makeLens(stochasticmode="MP")
            SOdraw=numpy.array(S[survey].SOdraw)
            if type(model)!=type(None):
                lastsurvey=survey[:3]+str(i)
            if S[survey].seeingtest=="Fail":
                lenspars["pf"][survey]={}
                lenspars["rfpf"][survey]={}
                for src in S[survey].sourcenumbers:
                    lenspars["pf"][survey][src]=False
                    lenspars["rfpf"][survey][src]=False
                continue#try next survey
        else:
            print "\t ... load model"
            S[survey].loadModel(model)
            S[survey].stochasticObserving(mode="MP",SOdraw=SOdraw)
            if S[survey].seeingtest=="Fail":
                lenspars["pf"][survey]={}
                for src in S[survey].sourcenumbers:
                    lenspars["pf"][survey][src]=False
                continue#try next survey
            S[survey].ObserveLens()

        print "\t ... get meta data"
        mag,msrc,SN,bestband,pf=S[survey].SourceMetaData(SNcutA=a,magcut=b,SNcutB=[c,d])
        lenspars["SN"][survey]={}
        lenspars["bestband"][survey]={}
        lenspars["pf"][survey]={}
        lenspars["resolved"][survey]={}
        lenspars["poptag"][survey]=i
        lenspars["seeing"][survey]=S[survey].seeing
        rfpf={}
        rfsn={}
        print "\t ... Sources: ", S[survey].sourcenumbers
        for src in S[survey].sourcenumbers:
            rfpf[src]=False
            rfsn[src]=[0]
            lenspars["mag"][src]=mag[src]
            lenspars["msrc"][src]=msrc[src]
            lenspars["SN"][survey][src]=SN[src]
            lenspars["bestband"][survey][src]=bestband[src]
            lenspars["pf"][survey][src]=pf[src]
            lenspars["resolved"][survey][src]=S[survey].resolved[src]
        if survey!="Euclid":
            print "\t ... not euclid"
            if S[survey].seeingtest!="Fail":
                if survey not in ["CFHT","CFHTa"]:
                    print "\t ... ... make lens"
                    S[survey].makeLens(noisy=True,stochasticmode="1P",SOdraw=SOdraw,MakeModel=False)
                    #rfpf,rfsn=S[survey].RingFinderSN(SNcutA=a,magcut=b,SNcutB=[c,d],mode="donotcrossconvolve")
                else:
                    rfpf,rfsn=S[survey].RingFinderSN(SNcutA=a,magcut=b,SNcutB=[c,d],mode="crossconvolve")
        lenspars["rfpf"][survey]=rfpf
        lenspars["rfsn"][survey]=rfsn


    print
    accept=False
    for survey in surveys:
        if lenspars["pf"][survey][1]:
            accept=True

    if accept:
        #S[survey].display(band="VIS",bands=["VIS","VIS","VIS"])
        #if Si>100:exit()
        Si+=1
        SSPL[Si]=lenspars.copy()
        if (Si+1)%1000==0:
            f=open("LensStats/%s_%s_Lens_stats_%i.pkl"%(experiment,sourcepop,chunk),"wb")
            cPickle.dump([frac,SSPL],f,2)
            f.close()
            SSPL={} # reset SSPL or memory fills up
            chunk+=1

    del L.lens[i]

  f=open("LensStats/%s_%s_Lens_stats_%i.pkl"%(experiment,sourcepop,chunk),"wb")
  cPickle.dump([frac,SSPL],f,2)
  f.close()
  print "my Si", Si

bl=[]
for j in SSPL.keys():
    try:
        if SSPL[j]["rfpf"][survey][1]:
            bl.append(SSPL[j]["b"][1])
    except KeyError:pass
