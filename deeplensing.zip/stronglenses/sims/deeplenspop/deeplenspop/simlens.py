import sys
from PIL import Image

# computation
import numpy as np
import copy

# i/o
import cPickle
import os
import json
from astropy.table import Table, vstack
from astropy.io import ascii
import pprint
pp = pprint.PrettyPrinter(indent=4)

# logging
import logging.config

# custom
from FastLensSim import *
from ColorizeFunction import Colorize


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# I/O
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
def check_file_exists(f_io, verbose=False):
    """Check if a file exists."""
    if os.path.isfile(f_io):
        exists = True
    else:
        exists = False
        if verbose:
            # print "File does not exist: " + f_io
            log.warning("file does not exist: " + f_io)

    return exists


# ------------------------------------------------------------------------------
def check_overwrite(f_io, overwrite=False, verbose=False):
    """Check if we want overwrite."""
    exists = check_file_exists(f_io, verbose=verbose)

    if exists:
        # if it exists ...
        if overwrite:
            # clobber  is true if allowed to overwrite
            # print "File exists. OVERWRITE: " + f_io
            log.warning("File exists. OVERWRITE: " + f_io)
            clobber = True
        else:
            # print "File exists: DO NOT OVERWRITE" + f_io
            log.warning("File exists: DO NOT OVERWRITE" + f_io)
            clobber = False
    else:
        clobber = True

    return clobber


# ------------------------------------------------------------------------------
def save_pickle(directory, file_type, data, lens_class, overwrite=False):
    """Save pickle file."""
    lenspars_file_name = "lenspars_class_" + str(lens_class).zfill(2) + ".pkl"
    file_type_dictionary = {
                            "lenspars": lenspars_file_name,
                            }

    # make output directory if necessary
    make_dir(directory)

    # Create file name
    f_io = directory + file_type_dictionary[file_type]

    # check for overwrite permission
    clobber = check_overwrite(f_io, overwrite=overwrite)
    if clobber:
        f = open(f_io, 'wb')
        cPickle.dump(data, f)
        f.close()
    else:
        # print "did not write to file"
        log.warning("did not write to file")


# --------------------------------------------------------------------
def save_data(dirs, sample_parameters,
              data, labels, ids, lenspars_set,
              inds_deshuffle=None, overwrite=False):
    """Save Data arrays."""
    log.info("-----------------------")
    log.info("Save All the Data")
    log.info("-----------------------")
    log.info(" ")
    # make output directory if necessary
    make_dir(dirs["data"])

    # make io list
    io_list = [
                ("xtrain_lenspop.npy", data),
                ("ytrain_lenspop.npy", labels),
                ("itrain_lenspop.npy", ids),
                ("lenspars_set.npy", lenspars_set)
            ]

    # add indices from shuffling
    if inds_deshuffle is not None:
        io_list.append(("inds_deshuffle.npy", inds_deshuffle))

    # loop over data to be saved
    for io in io_list:
        f_io = dirs["data"] + io[0]
        data_io = io[1]

        # check for overwrite permission
        clobber = check_overwrite(f_io, overwrite=overwrite)
        if clobber:
            np.save(f_io, data_io)
        else:
            # print "did not write to file"
            log.warning("did not write to file")

    # make metadata log
    save_metadata_log(dirs["datalist"], sample_parameters, overwrite=overwrite)
    collate_metadata_log(dirs["datalist"])




# --------------------------------------------------------------------
def save_image(dir_data,
               id_system,
               sim_set,
               id_class,
               sample_parameters,
               method_color="colorize"):
    """Save Images."""
    name_lens_class = "class_" +\
                      str(id_class).zfill(1) + "_" +\
                      sample_parameters['classes'][id_class]['name']

    # print id_system, type(id_system), str(id_system).zfill(5)
    f_io = "img_" + name_lens_class + "_" + str(id_system).zfill(5) + ".png"
    dir_io = dir_data + name_lens_class + "/"

    # make directory
    make_dir(dir_io)

    if method_color == "colorize":
        myimage = Colorize(dir_output=dir_io, outfile=f_io,
                           enhLevel=0.3,
                           Q=0.8,
                           Gcor=1.2,
                           Rcor=0.8,
                           Icor=1.0,
                           Alpha=0.06,
                           satCut=0.8)
        band_set = ["g_SDSS", "r_SDSS", "i_SDSS"]
        myimage.read_data_set(band_set, sim_set.image)
        myimage.ProcessFile()
    elif method_color == "colorimage":
        mydata = sim_set.makeColorLens()
        myshape = mydata.shape
        rgb_array = np.zeros(myshape, 'uint8')
        rgb_array[..., 0] = mydata[:, :, 0] * 256
        rgb_array[..., 1] = mydata[:, :, 1] * 256
        rgb_array[..., 2] = mydata[:, :, 2] * 256
        img = Image.fromarray(rgb_array, 'RGB')
        img.save(dir_io + f_io)

    return


# --------------------------------------------------------------------
def prepare_directory(user, sample_parameters):
    """Make data directories."""
    log.info("-----------------------")
    log.info("Prepare directories (variables)")
    log.info("-----------------------")

    id_data = sample_parameters["id_data"]

    # identify system directory appropriate for this system
    uname = os.uname()
    system_name = uname[1]
    log.info("... Running on system: "+ system_name)
    log.info(" ")
    if "des" in system_name:
        dir_system = "/data/des40.b/data/nord/"
    else:
        dir_system = "/Users/" + user + "/Dropbox/"

    # base dropbox directory
    dir_deeplensing = dir_system + "deeplensing/"

    # base data directory
    dir_data = dir_deeplensing + "Data/Simulation/SimLensPop/"

    # directory for the datalist
    dir_datalist_full = dir_data + "DataList/"

    # data directory for this run
    dir_data_full = dir_data + "Data" + str(id_data).zfill(3) + "/"

    # dirs
    dirs = {
            "data": dir_data_full,
            "datalist": dir_datalist_full
            }

    # check data set type
    if sample_parameters["data_set_type"] == "population":
        dirs["population"]  = dir_data_full + "Population/"

    # lens class
    for iclass, vclass in sample_parameters["classes"].iteritems():
        name_lens_class = str(iclass).zfill(1)
        name_class_base = "class_"
        name_class_value = name_class_base + name_lens_class
        dir_class_full = dir_data_full + name_class_value + "/"
        dirs[name_class_value] = dir_class_full


    return  dirs


# ------------------------------------------------------------------------------
def make_dir(dir):
    """Make Directories."""
    try:
        os.makedirs(dir)
    except OSError:
        if not os.path.isdir(dir):
            raise
    return 0



# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Metadata logging
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# def make_metadata_log(my_system):
def make_metadata_log(metadata_log):
    """Create Data Dictionary."""
    # metadata_log = my_system.__dict__
    log.info("Make Meta data Log")

    return metadata_log


# ------------------------------------------------------------------------------
def update_metadata_log(metadata_log, **kwargs):
    """Update Data Dictionary."""
    # loop over keyword arguments
    for k,v in kwargs.iteritems():
        metadata_log[k] = v

    return metadata_log


# ------------------------------------------------------------------------------
def save_metadata_log(dir_datalist, metadata_log, overwrite=False):
    """Save Model Data Dictionary."""
    log.info("-----------------------")
    log.info("Save metadata for this run")
    log.info("-----------------------")
    log.info(" ")
    make_dir(dir_datalist)
    id_data = metadata_log["id_data"]
    f_io =  "Data" + str(id_data).zfill(3) + "_Log" + ".json"
    f_io_full = dir_datalist + f_io

    # check for overwrite permission
    clobber = check_overwrite(f_io_full, overwrite=overwrite)
    if clobber:
        with open(f_io_full, 'w') as f:
            json.dump(metadata_log, f, sort_keys = True, indent = 4)
    else:
        # print "did not write to file"
        log.warning("did not write to file")

    return f_io_full



# ------------------------------------------------------------------------------
def load_metadata_log(dir_datalist, id_data):
    """Save Model Data Dictionary."""
    f_io =  "Data" + str(id_model).zfill(3) + "_Log" + ".json"
    f_io_full = dir_datalist + f_io

    with open(f_io_full) as data_file:
        metadata_log = json.load(data_file)

    return metadata_log


# ------------------------------------------------------------------------------
def collate_metadata_log(dir_datalist):
    """Collate Data Dictionary into single file."""
    log.info("-----------------------")
    log.info("Collate all metadata logs")
    log.info("-----------------------")
    log.info(" ")
    file_io_list = [
                    os.path.join(dir_datalist, f)
                    for f in os.listdir(dir_datalist)
                    if
                        (
                            os.path.isfile(os.path.join(dir_datalist, f))
                            and
                            f.endswith('.json')
                            )
                    ]

    i_count = 0
    for f_io in file_io_list:
        with open(f_io) as data_file:
            metadata = json.load(data_file)

        for k, v in metadata.iteritems():
            metadata[k] = [v]

        metadata = Table(metadata)
        if i_count == 0:
            metadata_master = metadata
        else:
            metadata_master = vstack([metadata_master, metadata], join_type='outer')

        i_count += 1

    if i_count > 0:
        file_io_master = dir_datalist + "metadata_master_log.csv"
        del metadata_master['classes']
        ascii.write(metadata_master, file_io_master,
                    delimiter=",",
                    fill_values=[(ascii.masked, '---')])
    else:
        log.warning("There are no metadata log files to combine!")


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# Logging
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# def make_log(id_data, id_model, id_analysis=None):
def setup_logging(default_path='logging.json',
                  default_level=logging.INFO,
                  env_key='LOG_CFG'):
    """Log all output data."""
    path = default_path
    value = os.getenv(env_key, None)
    if value:
        path = value
    if os.path.exists(path):
        with open(path, 'rt') as f:
            myconfig = json.load(f)
        logging.config.dictconfig(myconfig)
    else:
        logging.basicConfig(level=default_level)

    return

# --------------------------------------------------------------------
# --------------------------------------------------------------------
# Generate Lens Parameters
# --------------------------------------------------------------------
# --------------------------------------------------------------------
# --------------------------------------------------------------------
def generate_lenspars(params):
    """Set lens pars."""
    # 'g_SDSS': 24.370519353475789,
    # 'i_SDSS': 20.992404985468962,
    # 'r_SDSS': 22.433858036695487,
    lenspars = {
        'b': {1: 1.50459557390608167},
        'lens?': True,
        'mhalo': {1: 0.58579999999999999},
        'deltap': 0.,
        'ml': {'F814W_ACS': 23.700488839837011,
               'Y_UKIRT': 99.987330016400776,
               'z_SDSS': 23.384894670188533,
               'g_SDSS': 22.0,
               'r_SDSS': 21.6,
               'i_SDSS': 20.15},
        'ms': {1: {'F814W_ACS': 21.899000000000001,
                   'Y_UKIRT': 2145.7356,
                   'g_SDSS': 22.049399999999999,
                   'i_SDSS': 21.899000000000001,
                   'r_SDSS': 22.091000000000001,
                   'z_SDSS': 21.7044}},
        'mstar': {1: 24.700800000000001},
        'ps': {1: 112.89232455485484},
        'ql': 0.20065521218913041,
        'qs': {1: 0.59850689607147711},
        'rl': {'F814W_ACS': 0.58849609885759535,
               'Y_UKIRT': 0.58849609885759535,
               'g_SDSS': 0.58849609885759535,
               'i_SDSS': 0.58849609885759535,
               'r_SDSS': 0.58849609885759535,
               'z_SDSS': 0.58849609885759535},
        'rs': {1: 1.48655683444557},
        'sigl': 197.52337452393428,
        'xs': {1: 4.0},
        'ys': {1: 4.0},
        'zl': 0.64597976934717483,
        'zs': {1: 1.4413},
        'id_system': -1
    }

    [zl, zs, be, xs, ys, cl, ml_g, ml_r, ml_i, ml_z, ms_g, ms_r, ms_i, ms_z] = params
    lenspars['zs'][1] = zs
    lenspars['zl'] = zl
    lenspars['xs'][1] = xs
    lenspars['ys'][1] = ys
    lenspars['b'][1] = be
    lenspars['lens?'] = cl
    lenspars['ml']['g_SDSS'] = ml_g
    lenspars['ml']['r_SDSS'] = ml_r
    lenspars['ml']['i_SDSS'] = ml_i
    lenspars['ml']['z_SDSS'] = ml_z
    lenspars['ms']['g_SDSS'] = ms_g
    lenspars['ms']['r_SDSS'] = ms_r
    lenspars['ms']['i_SDSS'] = ms_i
    lenspars['ms']['z_SDSS'] = ms_z

    return lenspars


# --------------------------------------------------------------------
def generate_lenspars_set(sample_parameters, id_class=None):
    """Generate sample of lenspars."""
    log.info("-----------------------")
    log.info("Generate sets of lenspars")
    log.info("-----------------------")
    log.info(" ")
    # check the position of the sources for efficient lens generation
    check_source_position_limits(sample_parameters)

    # nb samples
    nb_sample = sample_parameters["classes"][id_class]["nb_sample"]

    # set ranges
    zlmin, zlmax = sample_parameters["zl_min"], sample_parameters["zl_max"]
    zsmin, zsmax = sample_parameters["zs_min"], sample_parameters["zs_max"]
    bemin, bemax = sample_parameters["be_min"], sample_parameters["be_max"]
    xsmin, xsmax = sample_parameters["xs_min"], sample_parameters["xs_max"]
    ysmin, ysmax = sample_parameters["ys_min"], sample_parameters["ys_max"]
    #par['ml']['g_SDSS']
    #par['ms'][1]['g_SDSS']

    ml_g_min, ml_g_max = sample_parameters["ml_g_min"], sample_parameters["ml_g_max"]
    ml_r_min, ml_r_max = sample_parameters["ml_r_min"], sample_parameters["ml_r_max"]
    ml_i_min, ml_i_max = sample_parameters["ml_i_min"], sample_parameters["ml_i_max"]
    ml_z_min, ml_z_max = sample_parameters["ml_z_min"], sample_parameters["ml_z_max"]

    ms_g_min, ms_g_max = sample_parameters["ms_g_min"], sample_parameters["ms_g_max"]
    ms_r_min, ms_r_max = sample_parameters["ms_r_min"], sample_parameters["ms_r_max"]
    ms_i_min, ms_i_max = sample_parameters["ms_i_min"], sample_parameters["ms_i_max"]
    ms_z_min, ms_z_max = sample_parameters["ms_z_min"], sample_parameters["ms_z_max"]

    cl = sample_parameters["classes"][id_class]["class"]

    # set lists
    be_list = []
    xs_list = []
    ys_list = []
    zs_list = []
    zl_list = []
    ml_g_list = []
    ml_r_list = []
    ml_i_list = []
    ml_z_list = []
    ms_g_list = []
    ms_r_list = []
    ms_i_list = []
    ms_z_list = []
    cl_list = []

    # set random seed
    np.random.seed(sample_parameters["seed"])

    # loop to get generate random parameters
    nb_sample_have = 0
    while nb_sample_have < nb_sample:

        # get random data
        be_tmp = np.random.uniform(bemin, bemax)
        xs_tmp = np.random.uniform(xsmin, xsmax)
        ys_tmp = np.random.uniform(ysmin, ysmax)
        zs_tmp = np.random.uniform(zsmin, zsmax)
        zl_tmp = np.random.uniform(zlmin, zlmax)

        ml_g_tmp = np.random.uniform(ml_g_min, ml_g_max)
        ml_r_tmp = np.random.uniform(ml_r_min, ml_r_max)
        ml_i_tmp = np.random.uniform(ml_i_min, ml_i_max)
        ml_z_tmp = np.random.uniform(ml_z_min, ml_z_max)

        ms_g_tmp = np.random.uniform(ms_g_min, ms_g_max)
        ms_r_tmp = np.random.uniform(ms_r_min, ms_r_max)
        ms_i_tmp = np.random.uniform(ms_i_min, ms_i_max)
        ms_z_tmp = np.random.uniform(ms_z_min, ms_z_max)

        # check status
        params_tmp = [be_tmp,
                      xs_tmp, ys_tmp,
                      zs_tmp, zl_tmp,
                      ml_g_tmp, ml_r_tmp, ml_i_tmp, ml_z_tmp,
                      ms_g_tmp, ms_r_tmp, ms_i_tmp, ms_z_tmp]
        #print 'params tmp:', nb_sample_have, nb_sample, params_tmp
        status = check_class_status(params_tmp, cl)

        # apply status
        if status:
            be_list.append(be_tmp)
            xs_list.append(xs_tmp)
            ys_list.append(ys_tmp)
            zs_list.append(zs_tmp)
            zl_list.append(zl_tmp)
            ml_g_list.append(ml_g_tmp)
            ml_r_list.append(ml_r_tmp)
            ml_i_list.append(ml_i_tmp)
            ml_z_list.append(ml_z_tmp)
            ms_g_list.append(ms_g_tmp)
            ms_r_list.append(ms_r_tmp)
            ms_i_list.append(ms_i_tmp)
            ms_z_list.append(ms_z_tmp)
            cl_list.append(cl)
            nb_sample_have = len(be_list)

    # convert to numpy arrays
    be_list = np.array(be_list)
    xs_list = np.array(xs_list)
    ys_list = np.array(ys_list)
    zs_list = np.array(zs_list)
    zl_list = np.array(zl_list)
    cl_list = np.array(cl_list)
    ml_g_list = np.array(ml_g_list)
    ml_r_list = np.array(ml_r_list)
    ml_i_list = np.array(ml_i_list)
    ml_z_list = np.array(ml_z_list)
    ms_g_list = np.array(ms_g_list)
    ms_r_list = np.array(ms_r_list)
    ms_i_list = np.array(ms_i_list)
    ms_z_list = np.array(ms_z_list)

    # store params
    params = np.array(
                [np.array([zli, zsi, bei, xsi, ysi, cli, ml_gi, ml_ri, ml_ii, ml_zi, ms_gi, ms_ri, ms_ii, ms_zi])
                for        zli, zsi, bei, xsi, ysi, cli, ml_gi, ml_ri, ml_ii, ml_zi, ms_gi, ms_ri, ms_ii, ms_zi
                in zip(zl_list, zs_list, be_list, xs_list, ys_list, cl_list,
                      ml_g_list, ml_r_list, ml_i_list, ml_z_list,
                      ms_g_list, ms_r_list, ms_i_list, ms_z_list)]
                )

    # create full array of lenspars parameters:
    # loop over lens parameters
    nb_params = len(params)
    lenspars_set = np.empty(nb_params, dtype=dict)
    for iparam, param in zip(range(nb_params), params):
        lenspars_set[iparam] = generate_lenspars(param)
        lenspars_set[iparam]['id_system'] = iparam

    return lenspars_set


# --------------------------------------------------------------------
def check_class_status(params_tmp, lens_class):
    """Check whether the object is a lens or not based on radius."""
    # get data
    [be_tmp, xs_tmp, ys_tmp, zs_tmp, zl_tmp, 
     ml_g_tmp, ml_r_tmp, ml_i_tmp, ml_z_tmp,
     ms_g_tmp, ms_r_tmp, ms_i_tmp, ms_z_tmp] = params_tmp

    # get boolean for within einstein radius adn within redshift
    radius = np.sqrt(xs_tmp**2 + ys_tmp**2)
    within_radius = bool(radius < be_tmp)
    within_redshift = bool(zl_tmp < zs_tmp)
    within = within_redshift and within_radius

    # print within_radius, within_redshift, within

    # check if meets class
    if within is lens_class:
        status = True
    else:
        status = False

        status = False

    return status


# --------------------------------------------------------------------
def check_status_combo(status_radius, status_redshift):
    """Check whether the object is a lens or not based on radius."""
    status = status_radius and status_redshift

    return status


# --------------------------------------------------------------------
def check_status_redshift(zs_tmp, zl_tmp, lens_class):
    """Check whether the object is a lens or not based on radius."""
    # get boolean for within redshift limits
    within = bool(zl_tmp < zs_tmp)

    # check if meets class
    if within is lens_class:
        status = True
    else:
        status = False

    return status


# --------------------------------------------------------------------
def check_status_radius(xs_tmp, ys_tmp, b_tmp, lens_class):
    """Check whether the object is a lens or not."""
    # measure distance of source
    radius2 = xs_tmp**2 + ys_tmp**2
    radius = np.sqrt(radius2)

    # get boolean for within einstein radius
    within = bool(radius < b_tmp)

    # check if meets class
    if within is lens_class:
        status = True
    else:
        status = False

    return status


# --------------------------------------------------------------------
# --------------------------------------------------------------------
# Generate Lens Sample
# --------------------------------------------------------------------
# --------------------------------------------------------------------
# --------------------------------------------------------------------
def check_source_position_limits(sample_parameters):
    """
    Check the source position.

    Check if the source position maximum value is
    beyond the range of having
    an efficient placement of sources
    """
    nb_side_pix = sample_parameters["nb_side_pix"]
    xs_min, xs_max = sample_parameters["xs_min"], sample_parameters["xs_max"]
    ys_min, ys_max = sample_parameters["ys_min"], sample_parameters["ys_max"]

    nb_side_sec = nb_side_pix * 0.263
    nb_side_sec_half = nb_side_sec / 2.

    xmax_abs = max([abs(xs) for xs in [xs_min, xs_max]])
    ymax_abs = max([abs(ys) for ys in [ys_min, ys_max]])
    rmax = np.sqrt(xmax_abs**2 + ymax_abs**2)
    if rmax > nb_side_sec_half:
        log.errors("Limits on position ranges create non-lenses inefficiently")
        log.errors("your radius: " +  str(rmax))
        log.errors(" max advisable radius: " + str(nb_side_sec_half))
        sys.exit()


# --------------------------------------------------------------------
def generate_labels(sample_parameters, id_class=None):
    """Generate labels for class of objects."""
    nb_sample = sample_parameters["classes"][id_class]["nb_sample"]
    base_list =  np.ones(nb_sample, dtype=int)
    labels = base_list * int(id_class)

    return labels


# --------------------------------------------------------------------
def generate_lens(lenspars, sample_parameters,
                  verbose_debug=False):
    """Generate image data for one lens or non-lens."""
    # survey = "Custom"
    nsources = 1
    SNcutA = 10
    magcut = 0
    SNcutBmin = 0
    SNcutBmax = 0
    myfloor = 999

    # sample parameters
    survey = sample_parameters["survey"]
    psf_fac = sample_parameters["psf_fac"]
    exp_fac = sample_parameters["exp_fac"]
    nb_side_pix = sample_parameters["nb_side_pix"]
    jiggle = sample_parameters["jiggle"]

    # Create Survey Simulation set
    sim_set = FastLensSim(survey, Nside_pix=nb_side_pix, verbose_debug=verbose_debug)
    sim_set.bfac = float(100000)  # high allows object to always be observed
    sim_set.rfac = float(0)     # low allows object to always be observed
    sim_set.exposuretimes['g_SDSS'] *= exp_fac
    sim_set.exposuretimes['r_SDSS'] *= exp_fac
    sim_set.exposuretimes['i_SDSS'] *= exp_fac

    # visible magnitude value
    lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                             lenspars["rl"]["i_SDSS"] +
                             lenspars["rl"]["z_SDSS"]) / 3

    # mi in ml
    for mi in [lenspars["ml"], lenspars["ms"][1]]:
        mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["SN"] = {}
    lenspars["bestband"] = {}
    lenspars["pf"] = {}
    lenspars["resolved"] = {}
    lenspars["poptag"] = {}
    lenspars["seeing"] = {}
    lenspars["rfpf"] = {}
    lenspars["rfsn"] = {}

    sim_set.setLensPars(lenspars["ml"],
                       lenspars["rl"],
                       lenspars["ql"],
                       lenspars["deltap"],
                       reset=True,
                       jiggle=jiggle)

    # set source parameters
    for j in range(nsources):
        jj = j + 1
        sim_set.setSourcePars(lenspars["b"][jj],
                             lenspars["ms"][jj],
                             lenspars["xs"][jj],
                             lenspars["ys"][jj],
                             lenspars["qs"][jj],
                             lenspars["ps"][jj],
                             lenspars["rs"][jj],
                             sourcenumber=jj)
    if verbose_debug:
        # print "len pre", len(sim_set.image)
        print "generate lens: makeLens A", len(sim_set.image)
    sim_set.makeLens(stochasticmode="MP",
                    musthaveallbands=True,
                    psf_fac=psf_fac,
                    myfloor=myfloor)
    SOdraw = numpy.array(sim_set.SOdraw)
    if verbose_debug:
        print "generate lens: makeLens B", len(sim_set.image)

    mag, msrc, SN, bestband, pf = \
        sim_set.SourceMetaData(SNcutA=SNcutA,
                              magcut=magcut,
                              SNcutB=[SNcutBmin, SNcutBmax])

    # create some lenspars elements
    lenspars["SN"][survey] = {}
    lenspars["bestband"][survey] = {}
    lenspars["pf"][survey] = {}
    lenspars["resolved"][survey] = {}
    lenspars["seeing"][survey] = sim_set.seeing

    rfpf = {}
    rfsn = {}
    for src in sim_set.sourcenumbers:
        rfpf[src] = False
        rfsn[src] = [0]
        lenspars["mag"][src] = mag[src]
        lenspars["msrc"][src] = msrc[src]
        lenspars["SN"][survey][src] = SN[src]
        lenspars["bestband"][survey][src] = bestband[src]
        lenspars["pf"][survey][src] = pf[src]
        lenspars["resolved"][survey][src] = sim_set.resolved[src]

    if verbose_debug:
        #    print "len secondary", len(sim_set.image)
        print "generate lens: makeLens C", len(sim_set.image)

    sim_set.makeLens(noisy=True,
                    stochasticmode="MP",
                    SOdraw=SOdraw,
                    musthaveallbands=True,
                    MakeModel=True,
                    psf_fac=psf_fac,
                    myfloor=myfloor)

    if verbose_debug:
        print "generate lens: makeLens D", len(sim_set.image)
    lenspars["rfpf"][survey] = rfpf
    lenspars["rfsn"][survey] = rfsn

    if verbose_debug:
        print
        print
        print

    return sim_set


# --------------------------------------------------------------------
def extract_simulation_image(sim_set):
    """Get image data from simulation data structure."""
    img = [y for x, y in sim_set.image.iteritems()]

    return img



# --------------------------------------------------------------------
def generate_lens_sample(dir_data,
                         lenspars_set,
                         sample_parameters,
                         id_class=None,
                         ids_start=0,
                         verbose_object=False,
                         verbose_debug=False,
                         method_color="colorize",
                         nb_verbose=500
                         ):
    """Generate sample of lenses from set of lenspars."""
    # create shape for data
    log.info("-----------------------")
    log.info("Generate Sample of Lenses: class " + str(id_class))
    log.info("-----------------------")
    nb_sample = sample_parameters["classes"][id_class]['nb_sample']
    data_shape = (nb_sample,
                  sample_parameters["nb_channels"],
                  sample_parameters["nb_side_pix"],
                  sample_parameters["nb_side_pix"]
                )

    # create ids, data set and labels
    data = np.empty(data_shape)
    inds = np.arange(nb_sample, dtype=int)
    labels = generate_labels(sample_parameters, id_class=id_class)
    ids = np.empty(nb_sample, dtype=int)

    # loop over systems (with their lens parameters)
    if nb_verbose < nb_sample:
        log.info(" ")
        log.info( "Percent Complete (current / total)")
        log.info( "...................................")
    for ind, lenspars in zip(inds, lenspars_set):
        if (ind+1)%nb_verbose == 0:
            str_percentage = str(float(ind)/float(nb_sample)*100.) + "%"
            str_count = "(" + str(ind+1) + " / " + str(nb_sample) + ")"
            log.info("  " + str_percentage + " " + str_count)

        # simulate lens
        sim_set = generate_lens(lenspars, sample_parameters, verbose_debug=verbose_debug)

        # append data on system
        data[ind] = np.array(extract_simulation_image(sim_set))

        # update ids
        ids[ind] = ind + ids_start
        lenspars_set[ind]["id_system"] = ids[ind]
        #pp.pprint(lenspars_set[ind])

        # save color image
        save_image(dir_data, ids[ind], sim_set, id_class, sample_parameters, method_color=method_color)

        # print to see what's happening
        if verbose_debug:
            log.info('  object', ids_tmp, id_class, len(sim_set.image))

    return data, labels, ids, lenspars_set


# --------------------------------------------------------------------
def combine_data(data_list, labels_list, ids_list, lenspars_list):
    """Combine data."""
    # concatenate data arrays
    log.info("-----------------------")
    log.info("Combine Data Arrays")
    log.info("-----------------------")
    log.info(" ")

    # count numbers of data sets
    nb_data_set = len(data_list)
    nb_labels_set = len(labels_list)
    nb_ids_set = len(ids_list)
    nb_lenspars_set = len(lenspars_list)

    # check numbers are the same
    text_assert_numbers = str(nb_data_set).zfill(2) + " " +\
                          str(nb_labels_set).zfill(2) + " " +\
                          str(nb_ids_set).zfill(2) + " " +\
                          str(nb_lenspars_set).zfill(2)
    text_assert = "Different lengths for sets of data: nb data, nb labels, nb ids: "
    nb_assert = (nb_data_set == nb_labels_set == nb_ids_set == nb_lenspars_set)
    assert nb_assert, text_assert + text_assert_numbers

    # combine data lists into tuples for concatenation
    nb_list = nb_data_set
    if nb_list > 1:
        data_tuple = ()
        labels_tuple = ()
        ids_tuple = ()
        lenspars_tuple = ()
        for data, labels, ids, lenspars in zip(data_list, labels_list, ids_list, lenspars_list):
            data_tuple += (data,)
            labels_tuple += (labels,)
            ids_tuple += (ids,)
            lenspars_tuple += (lenspars,)

        # concatenate
        data = np.concatenate(data_tuple)
        labels = np.concatenate(labels_tuple)
        ids = np.concatenate(ids_tuple)
        lenspars = np.concatenate(lenspars_tuple)

    return data, labels, ids, lenspars


# --------------------------------------------------------------------
def make_shuffle_indices(ndata):
    """Create indices: original and shuffle."""
    log.info("-----------------------")
    log.info("Shuffle Indices ")
    log.info("-----------------------")
    log.info(" ")
    # create index arrays
    inds = np.arange(ndata)

    # copy for shuffling
    inds_shuffle = copy.deepcopy(inds)

    # shuffle these indices only
    np.random.shuffle(inds_shuffle)

    # get indices for de-shuffling
    inds_deshuffle = np.argsort(inds_shuffle)

    return inds_shuffle, inds_deshuffle


# --------------------------------------------------------------------
def shuffle_data(inds_shuffle, data, labels, ids, lenspars):
    """Shuffle data."""
    data_shuffle = data[inds_shuffle]
    labels_shuffle = labels[inds_shuffle]
    ids_shuffle = ids[inds_shuffle]
    lenspars_shuffle = lenspars[inds_shuffle]

    return data_shuffle, labels_shuffle, ids_shuffle, lenspars_shuffle


# --------------------------------------------------------------------
def deshuffle_data(inds_deshuffle, data_shuffle, labels_shuffle, ids_shuffle):
    """Deshuffle data."""
    data = data_shuffle[inds_deshuffle]
    labels = labels_shuffle[inds_deshuffle]
    ids = ids_shuffle[inds_deshuffle]

    return data, labels, ids


# ------------------------------------------------------------------------------
def get_directory_info(directory):
    """Get directory and file information."""
    files = [os.path.join(directory,fn) for fn in next(os.walk(directory))[2]]
    return files, len(files)


# ------------------------------------------------------------------------------
def load_lenspars_pop(dir_pop, id_class):
    """Read lenspars for populations."""
    # create dictionary
    log.info("-----------------------")
    log.info("Load Lenspars for Populations: class " + str(id_class))
    log.info("-----------------------")
    log.info(" ")
    dir_data = {
                    0: dir_pop + "class_0_nons/",
                    1: dir_pop + "class_1_lens/"
                }

    # Get directory information
    files, nb_files = get_directory_info(dir_data[id_class])

    # check if there are ny files in the directory
    if nb_files < 1:
        log.warning("There are no files in this dictionary.")
        return -1

    # loop over files and read in
    lenspars = []
    for file_tmp in files:

        # check if file exists
        exists = check_file_exists(file_tmp)

        # load or not, according to exists
        if exists:
            f = open(file_tmp, 'rb')
            lenspars_tmp = cPickle.load(f)
            f.close()

            for keys, pars in lenspars_tmp.iteritems():
                lenspars.append(pars)
        else:
            log.warning("file does not exist: " + file_tmp)

    return lenspars


# ==============================================================================
# Main setup
# ==============================================================================
if __name__ == '__main__':
    print "main"
else:
    setup_logging()
    log = logging.getLogger(__name__)
