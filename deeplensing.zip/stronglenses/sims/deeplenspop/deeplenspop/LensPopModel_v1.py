import os
from astropy.io import fits
from FastLensSim import *
from ColorizeFunction import Colorize


def SaveImages(i, S):
    """Save Images"""
    folder = "SimImages/%i" % (i)
    if not os.path.isdir(folder):
        os.mkdir(folder)
    print "\t ... my folder", folder
    for band in SimSet[survey].bands:
        print "test", band
        img = SimSet[survey].image[band]
        sig = SimSet[survey].sigma[band]
        psf = SimSet[survey].psf[band]
        resid = SimSet[survey].fakeResidual[0][band]  # The lens subtracted

        fits.PrimaryHDU(img).writeto("%s/image_%s.fits" %
                                     (folder, band),
                                     clobber=True)
        fits.PrimaryHDU(sig).writeto("%s/sigma_%s.fits" %
                                     (folder, band),
                                     clobber=True)
        fits.PrimaryHDU(psf).writeto("%s/psf_%s.fits" %
                                     (folder, band),
                                     clobber=True)
        fits.PrimaryHDU(resid).writeto(
            "%s/galsub_%s.fits" % (folder, band), clobber=True)

    dir_input = folder + "/"
    filenameG = "image_g_SDSS.fits"
    filenameR = "image_r_SDSS.fits"
    filenameI = "image_i_SDSS.fits"
    myimage = Colorize(dir_input, filenameG, filenameR, filenameI)
    myimage.ProcessFile()


# Constants
sigfloor = 300
frac = 0.001
a = 150  # SN threshold
b = 10  # Magnification threshold
c = 2000
d = 2000
nall = 5
nsources = 1
experiment = "LSST"
survey = "LSSTa"
sourcepop = "lsst"

# Create Survey Simulation set
SimSet = {}
SimSet[survey] = FastLensSim(survey, fractionofseeing=1)
SimSet[survey].bfac = float(2)
SimSet[survey].rfac = float(2)

# set lens pars
lenspars = {
    'zl': 0.5,
    'zs': {1: 2.5},
    'ps': {1: 38.250903302932855},
    'qs': {1: 0.19031817426687943},
    'b': {1: 2.5},
    'lens?': True,
    'rs': {1: 0.31273429289548288},
    'ml': {
        'g_SDSS': 25.764342164961832,
        'r_SDSS': 22.918909056282573,
        'i_SDSS': 21.669371051501813,
        'z_SDSS': 20.353736610804404,
        'F814W_ACS': 21.008432268442618,
        'Y_UKIRT': 19.78383167424828
    },
    'sigl': 291.03020182762191,
    'mhalo': {1: 0.46039999999999998},
    'ms': {1: {
        'g_SDSS': 21.38,
        'r_SDSS': 21.60,
        'i_SDSS': 21.58,
        'z_SDSS': 21.55,
        'F814W_ACS': 21.58,
        'Y_UKIRT': 2128.5093999999999
    }},
    'rl': {
        'r_SDSS': 0.47511297207625075,
        'z_SDSS': 0.47511297207625075,
        'F814W_ACS': 0.47511297207625075,
        'Y_UKIRT': 0.47511297207625075,
        'g_SDSS': 0.47511297207625075,
        'i_SDSS': 0.47511297207625075},
    'xs': {1: 0.3146192669123881},
    'ys': {1: 0.3029063512358129409},
    'mstar': {1: 20.397600000000001},
    'ql': 0.61276676378304762
}


print "about to load"
print "loop over lenses", nall
for i in range(1, nall):

    print "\t set lens pars"
    # visible magnitude value
    lenspars["rl"]["VIS"] = (lenspars["rl"]["r_SDSS"] +
                             lenspars["rl"]["i_SDSS"] +
                             lenspars["rl"]["z_SDSS"]) / 3
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["mag"] = {}
    lenspars["msrc"] = {}
    lenspars["SN"] = {}
    lenspars["bestband"] = {}
    lenspars["pf"] = {}
    lenspars["resolved"] = {}
    lenspars["poptag"] = {}
    lenspars["seeing"] = {}
    lenspars["rfpf"] = {}
    lenspars["rfsn"] = {}

    # mi in ml
    for mi in [lenspars["ml"], lenspars["ms"][1]]:
        mi["VIS"] = (mi["r_SDSS"] + mi["i_SDSS"] + mi["z_SDSS"]) / 3

    print "\t ... set lens pars"
    SimSet[survey].setLensPars(lenspars["ml"],
                               lenspars["rl"],
                               lenspars["ql"],
                               reset=True)

    # set source parameters
    for j in range(nsources):
        jj = j + 1
        SimSet[survey].setSourcePars(lenspars["b"][jj],
                                     lenspars["ms"][jj],
                                     lenspars["xs"][jj],
                                     lenspars["ys"][jj],
                                     lenspars["qs"][jj],
                                     lenspars["ps"][jj],
                                     lenspars["rs"][jj],
                                     sourcenumber=jj)

    print "\t ... not last survey"
    model = SimSet[survey].makeLens(stochasticmode="MP")
    SOdraw = numpy.array(SimSet[survey].SOdraw)

    print "\t ... get meta data"
    mag, msrc, SN, bestband, pf = \
        SimSet[survey].SourceMetaData(SNcutA=a,
                                      magcut=b,
                                      SNcutB=[c, d])

    lenspars["SN"][survey] = {}
    lenspars["bestband"][survey] = {}
    lenspars["pf"][survey] = {}
    lenspars["resolved"][survey] = {}
    lenspars["poptag"][survey] = i
    lenspars["seeing"][survey] = SimSet[survey].seeing
    rfpf = {}
    rfsn = {}

    print "\t ... Sources: ", SimSet[survey].sourcenumbers
    for src in SimSet[survey].sourcenumbers:
        rfpf[src] = False
        rfsn[src] = [0]
        lenspars["mag"][src] = mag[src]
        lenspars["msrc"][src] = msrc[src]
        lenspars["SN"][survey][src] = SN[src]
        lenspars["bestband"][survey][src] = bestband[src]
        lenspars["pf"][survey][src] = pf[src]
        lenspars["resolved"][survey][src] = SimSet[survey].resolved[src]

    print "\t ... ... make lens"
    SimSet[survey].makeLens(noisy=True,
                            stochasticmode="1P",
                            SOdraw=SOdraw,
                            MakeModel=False)

    lenspars["rfpf"][survey] = rfpf
    lenspars["rfsn"][survey] = rfsn

    # save images to file
    SaveImages(i, SimSet)
